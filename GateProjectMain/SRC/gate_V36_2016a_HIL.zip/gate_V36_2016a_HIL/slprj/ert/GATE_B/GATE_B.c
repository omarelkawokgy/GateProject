/*
 * File: GATE_B.c
 *
 * Code generated for Simulink model 'GATE_B'.
 *
 * Model version                  : 1.342
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Wed Mar 07 02:26:36 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "GATE_B.h"
#include "GATE_B_private.h"

/* System initialize for referenced model: 'GATE_B' */
void GATE_B_Init(boolean_T *rty_greenLedPin, boolean_T *rty_redLedPin, boolean_T
                 *rty_yellowLedPin, boolean_T *rty_LeftMotorPin, boolean_T
                 *rty_CommonMotorPin, boolean_T *rty_rightMotorPin, boolean_T
                 *rty_bulbPin, real_T *rty_BT_TxChar, boolean_T
                 *rty_passAssigned, uint8_T rty_passwordOut[6])
{
  int16_T i;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtgreenLedPinInport1' */
  *rty_greenLedPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtredLedPinInport1' */
  *rty_redLedPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtyellowLedPinInport1' */
  *rty_yellowLedPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtLeftMotorPinInport1' */
  *rty_LeftMotorPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtCommonMotorPinInport1' */
  *rty_CommonMotorPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtrightMotorPinInport1' */
  *rty_rightMotorPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtbulbPinInport1' */
  *rty_bulbPin = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtBT_TxCharInport1' */
  *rty_BT_TxChar = 0.0;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtpassAssignedInport1' */
  *rty_passAssigned = false;

  /* SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtpasswordOutInport1' */
  for (i = 0; i < 6; i++) {
    rty_passwordOut[i] = 0U;
  }

  /* End of SystemInitialize for SignalConversion: '<Root>/TmpSignal ConversionAtpasswordOutInport1' */
}

/* Output and update for referenced model: 'GATE_B' */
void GATE_B(boolean_T *rty_greenLedPin, boolean_T *rty_redLedPin, boolean_T
            *rty_yellowLedPin, boolean_T *rty_LeftMotorPin, boolean_T
            *rty_CommonMotorPin, boolean_T *rty_rightMotorPin, boolean_T
            *rty_bulbPin, real_T *rty_BT_TxChar, boolean_T *rty_passAssigned,
            uint8_T rty_passwordOut[6])
{
  int16_T i;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtgreenLedPinInport1' */
  *rty_greenLedPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtredLedPinInport1' */
  *rty_redLedPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtyellowLedPinInport1' */
  *rty_yellowLedPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtLeftMotorPinInport1' */
  *rty_LeftMotorPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtCommonMotorPinInport1' */
  *rty_CommonMotorPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtrightMotorPinInport1' */
  *rty_rightMotorPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtbulbPinInport1' */
  *rty_bulbPin = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtBT_TxCharInport1' */
  *rty_BT_TxChar = 0.0;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtpassAssignedInport1' */
  *rty_passAssigned = false;

  /* SignalConversion: '<Root>/TmpSignal ConversionAtpasswordOutInport1' */
  for (i = 0; i < 6; i++) {
    rty_passwordOut[i] = 0U;
  }

  /* End of SignalConversion: '<Root>/TmpSignal ConversionAtpasswordOutInport1' */
}

/* Model initialize function */
void GATE_B_initialize(const char_T **rt_errorStatus, RT_MODEL_GATE_B_T *const
  GATE_B_M)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatusPointer(GATE_B_M, rt_errorStatus);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
