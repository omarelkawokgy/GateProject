/*
 * File: GATE_B_types.h
 *
 * Code generated for Simulink model 'GATE_B'.
 *
 * Model version                  : 1.342
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Wed Mar 07 02:26:36 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_GATE_B_types_h_
#define RTW_HEADER_GATE_B_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_GATE_B_T RT_MODEL_GATE_B_T;

#endif                                 /* RTW_HEADER_GATE_B_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
