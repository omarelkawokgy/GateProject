/*
 * File: GATE_B.h
 *
 * Code generated for Simulink model 'GATE_B'.
 *
 * Model version                  : 1.342
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Wed Mar 07 02:26:36 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_GATE_B_h_
#define RTW_HEADER_GATE_B_h_
#ifndef GATE_B_COMMON_INCLUDES_
# define GATE_B_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* GATE_B_COMMON_INCLUDES_ */

#include "GATE_B_types.h"

/* Shared type includes */
#include "model_reference_types.h"

/* Real-time Model Data Structure */
struct tag_RTM_GATE_B_T {
  const char_T **errorStatus;
};

typedef struct {
  RT_MODEL_GATE_B_T rtm;
} MdlrefDW_GATE_B_T;

/* Model reference registration function */
extern void GATE_B_initialize(const char_T **rt_errorStatus, RT_MODEL_GATE_B_T *
  const GATE_B_M);
extern void GATE_B_Init(boolean_T *rty_greenLedPin, boolean_T *rty_redLedPin,
  boolean_T *rty_yellowLedPin, boolean_T *rty_LeftMotorPin, boolean_T
  *rty_CommonMotorPin, boolean_T *rty_rightMotorPin, boolean_T *rty_bulbPin,
  real_T *rty_BT_TxChar, boolean_T *rty_passAssigned, uint8_T rty_passwordOut[6]);
extern void GATE_B(boolean_T *rty_greenLedPin, boolean_T *rty_redLedPin,
                   boolean_T *rty_yellowLedPin, boolean_T *rty_LeftMotorPin,
                   boolean_T *rty_CommonMotorPin, boolean_T *rty_rightMotorPin,
                   boolean_T *rty_bulbPin, real_T *rty_BT_TxChar, boolean_T
                   *rty_passAssigned, uint8_T rty_passwordOut[6]);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'GATE_B'
 * '<S1>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF'
 * '<S2>'   : 'GATE_B/B_Variant_KP_RF'
 * '<S3>'   : 'GATE_B/CurrentFilterSubsystem'
 * '<S4>'   : 'GATE_B/Subsystem1'
 * '<S5>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF/LedHandler'
 * '<S6>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF/MotorHandler'
 * '<S7>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF/SquareWaveCreator'
 * '<S8>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler'
 * '<S9>'   : 'GATE_B/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler_old1'
 * '<S10>'  : 'GATE_B/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler'
 * '<S11>'  : 'GATE_B/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler1'
 * '<S12>'  : 'GATE_B/B_HardwareOutputWrapper_KP_RF/SquareWaveCreator/SquareWaveCreator'
 * '<S13>'  : 'GATE_B/B_Variant_KP_RF/GateLogicStatemachine'
 * '<S14>'  : 'GATE_B/CurrentFilterSubsystem/10msSmapler'
 * '<S15>'  : 'GATE_B/CurrentFilterSubsystem/Subsystem'
 * '<S16>'  : 'GATE_B/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector'
 * '<S17>'  : 'GATE_B/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector1'
 * '<S18>'  : 'GATE_B/Subsystem1/10msSmapler'
 * '<S19>'  : 'GATE_B/Subsystem1/Subsystem'
 */
#endif                                 /* RTW_HEADER_GATE_B_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
