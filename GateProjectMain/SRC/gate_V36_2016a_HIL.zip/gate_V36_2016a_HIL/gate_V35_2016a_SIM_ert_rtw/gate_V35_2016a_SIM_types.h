/*
 * gate_V35_2016a_SIM_types.h
 *
 * Code generation for model "gate_V35_2016a_SIM".
 *
 * Model version              : 1.340
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V35_2016a_SIM_types_h_
#define RTW_HEADER_gate_V35_2016a_SIM_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_gate_V35_2016a_SIM_T_ P_gate_V35_2016a_SIM_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_gate_V35_2016a_SIM_T RT_MODEL_gate_V35_2016a_SIM_T;

#endif                                 /* RTW_HEADER_gate_V35_2016a_SIM_types_h_ */
