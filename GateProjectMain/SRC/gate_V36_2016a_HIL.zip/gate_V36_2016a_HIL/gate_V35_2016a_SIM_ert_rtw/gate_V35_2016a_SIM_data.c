/*
 * File: gate_V35_2016a_SIM_data.c
 *
 * Code generated for Simulink model 'gate_V35_2016a_SIM'.
 *
 * Model version                  : 1.340
 * Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
 * C/C++ source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "gate_V35_2016a_SIM.h"
#include "gate_V35_2016a_SIM_private.h"

/* Block parameters (auto storage) */
P_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_P = {
  2950.0F,                             /* Variable: CLOSE_SIDE_VALUE
                                        * Referenced by: '<S23>/CLOSE_SIDE_VALUE'
                                        */
  60000U,                              /* Variable: MOVING_TIMER
                                        * Referenced by: '<S23>/MOVING_TIMER'
                                        */
  1000U,                               /* Variable: CURRENT_THRESH
                                        * Referenced by:
                                        *   '<S36>/WRONG_PASSWORD2'
                                        *   '<S36>/WRONG_PASSWORD3'
                                        */
  4000U,                               /* Variable: OPEN_SIDE_VALUE
                                        * Referenced by: '<S23>/OPEN_SIDE_VALUE'
                                        */
  10000U,                              /* Variable: PASS_TIMEOUT
                                        * Referenced by: '<S23>/PASS_TIMEOUT'
                                        */
  12U,                                 /* Variable: CLOSED
                                        * Referenced by:
                                        *   '<S23>/CLOSED'
                                        *   '<S26>/CLOSED'
                                        *   '<S27>/CLOSED'
                                        */
  42U,                                 /* Variable: CLOSE_CHAR
                                        * Referenced by:
                                        *   '<S23>/CLOSE_CHAR'
                                        *   '<S26>/CLOSE_CHAR'
                                        */
  13U,                                 /* Variable: CLOSING
                                        * Referenced by:
                                        *   '<S23>/CLOSING'
                                        *   '<S26>/CLOSING'
                                        *   '<S27>/CLOSING'
                                        */
  200U,                                /* Variable: CURRENT_STABLE_TIMER
                                        * Referenced by:
                                        *   '<S36>/WRONG_PASSWORD'
                                        *   '<S36>/WRONG_PASSWORD1'
                                        */
  15U,                                 /* Variable: INIT
                                        * Referenced by:
                                        *   '<S23>/INIT'
                                        *   '<S26>/INIT'
                                        *   '<S27>/OPENING1'
                                        */
  6U,                                  /* Variable: NO_PASS_ASSIG
                                        * Referenced by:
                                        *   '<S23>/NO_PASS_ASSIG'
                                        *   '<S26>/NO_PASS_ASSIG'
                                        */
  14U,                                 /* Variable: OPEN
                                        * Referenced by:
                                        *   '<S23>/OPEN'
                                        *   '<S26>/OPEN'
                                        *   '<S27>/OPEN'
                                        */
  11U,                                 /* Variable: OPENING
                                        * Referenced by:
                                        *   '<S23>/OPENING'
                                        *   '<S26>/OPENING'
                                        *   '<S27>/OPENING'
                                        */
  1U,                                  /* Variable: OPENING_ACTIVE
                                        * Referenced by: '<S23>/OPENING_ACTIVE'
                                        */
  35U,                                 /* Variable: OPEN_CHAR
                                        * Referenced by:
                                        *   '<S23>/OPEN_CHAR'
                                        *   '<S26>/OPEN_CHAR'
                                        */
  5U,                                  /* Variable: PASSWORD_VERIFIED
                                        * Referenced by:
                                        *   '<S23>/PASSWORD_VERIFIED'
                                        *   '<S26>/PASSWORD_VERIFIED'
                                        */
  7U,                                  /* Variable: PASS_ASSIGNED
                                        * Referenced by: '<S23>/PASS_ASSIGNED'
                                        */
  8U,                                  /* Variable: PASS_INCOMPLETE
                                        * Referenced by: '<S23>/PASS_INCOMPLETE'
                                        */
  255U,                                /* Variable: STABLE_TIMER_VALUE
                                        * Referenced by: '<S23>/STABLE_TIMER_VALUE'
                                        */
  9U,                                  /* Variable: TIMEOUT
                                        * Referenced by:
                                        *   '<S23>/TIMEOUT'
                                        *   '<S26>/TIMEOUT'
                                        */
  2U,                                  /* Variable: WRONG_PASSWORD
                                        * Referenced by:
                                        *   '<S23>/WRONG_PASSWORD'
                                        *   '<S26>/WRONG_PASSWORD'
                                        */
  12U,                                 /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S44>/Digital Output'
                                        */
  11U,                                 /* Mask Parameter: DigitalOutput_pinNumber_m
                                        * Referenced by: '<S43>/Digital Output'
                                        */
  13U,                                 /* Mask Parameter: DigitalOutput_pinNumber_e
                                        * Referenced by: '<S45>/Digital Output'
                                        */
  0U,                                  /* Computed Parameter: UnitDelay3_InitialCondition
                                        * Referenced by: '<S3>/Unit Delay3'
                                        */
  0,                                   /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S15>/Unit Delay'
                                        */
  0,                                   /* Computed Parameter: UnitDelay1_InitialCondition
                                        * Referenced by: '<S15>/Unit Delay1'
                                        */
  0,                                   /* Computed Parameter: UnitDelay2_InitialCondition
                                        * Referenced by: '<S15>/Unit Delay2'
                                        */
  0,                                   /* Computed Parameter: UnitDelay_InitialCondition_a
                                        * Referenced by: '<S36>/Unit Delay'
                                        */
  0,                                   /* Computed Parameter: UnitDelay1_InitialCondition_e
                                        * Referenced by: '<S36>/Unit Delay1'
                                        */
  0,                                   /* Computed Parameter: UnitDelay2_InitialCondition_d
                                        * Referenced by: '<S3>/Unit Delay2'
                                        */
  0,                                   /* Computed Parameter: UnitDelay_InitialCondition_e
                                        * Referenced by: '<S11>/Unit Delay'
                                        */
  0                                    /* Computed Parameter: UnitDelay1_InitialCondition_a
                                        * Referenced by: '<S11>/Unit Delay1'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
