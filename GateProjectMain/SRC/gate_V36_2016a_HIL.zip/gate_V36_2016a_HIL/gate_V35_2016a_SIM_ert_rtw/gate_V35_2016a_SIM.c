/*
 * gate_V35_2016a_SIM.c
 *
 * Code generation for model "gate_V35_2016a_SIM".
 *
 * Model version              : 1.340
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "gate_V35_2016a_SIM.h"
#include "gate_V35_2016a_SIM_private.h"

/* Named constants for Chart: '<S36>/rightSquareWaveDetector' */
#define gate_V35_2016a_SIM_IN_High     ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_Low      ((uint8_T)2U)
#define gate_V35_2016a_SIM_IN_Running  ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_Stop     ((uint8_T)2U)
#define gate_V35_201_IN_NO_ACTIVE_CHILD ((uint8_T)0U)

/* Named constants for Chart: '<S11>/EEPROM_Control' */
#define gate_V35_2016a_SIM_IN_Idle     ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_Read     ((uint8_T)2U)
#define gate_V35_2016a_SIM_IN_clear    ((uint8_T)3U)
#define gate_V35_2016a_SIM_IN_sendData ((uint8_T)4U)
#define gate_V35_2016a_SIM_IN_write    ((uint8_T)5U)
#define gate_V35_2_IN_NO_ACTIVE_CHILD_g ((uint8_T)0U)

/* Named constants for Chart: '<S26>/LedHandler' */
#define gate_V35_2016a_IN_AssigningPass ((uint8_T)1U)
#define gate_V35_2016a_IN_IncorrectPass ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_GateOn   ((uint8_T)3U)
#define gate_V35_2016a_SIM_IN_Idle_g   ((uint8_T)4U)
#define gate_V35_2016a_SIM_IN_Start    ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_Start_l  ((uint8_T)2U)
#define gate_V35_2016a_S_IN_correctPass ((uint8_T)3U)
#define gate_V35_2016a__IN_EnteringPass ((uint8_T)2U)
#define gate_V35_IN_correctPassAssigned ((uint8_T)2U)
#define gate_V_IN_incorrectPassAssigned ((uint8_T)3U)

/* Named constants for Chart: '<S23>/GateLogicStatemachine' */
#define gate_V35_2016a_IN_KpPassHandler ((uint8_T)1U)
#define gate_V35_2016a_IN_initTrailPass ((uint8_T)2U)
#define gate_V35_2016a_IN_openRightSide ((uint8_T)2U)
#define gate_V35_2016a_SIM_IN_addToPass ((uint8_T)3U)
#define gate_V35_2016a_SIM_IN_closed   ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_closing  ((uint8_T)2U)
#define gate_V35_2016a_SIM_IN_closing_g ((uint8_T)1U)
#define gate_V35_2016a_SIM_IN_gateOpen ((uint8_T)2U)
#define gate_V35_2016a_SIM_IN_idle     ((uint8_T)3U)
#define gate_V35_2016a_SIM_IN_init     ((uint8_T)3U)
#define gate_V35_2016a_SIM_IN_open     ((uint8_T)4U)
#define gate_V35_2016a_SIM_IN_opening  ((uint8_T)5U)
#define gate_V35_2016a_SI_IN_AssignPass ((uint8_T)1U)
#define gate_V35_2016a_SI_IN_btnPressed ((uint8_T)1U)
#define gate_V35_2016a_SI_IN_verifyPass ((uint8_T)4U)
#define gate_V35_2016a_S_IN_openingGate ((uint8_T)3U)
#define gate_V35_2016a__IN_MonitorInput ((uint8_T)2U)
#define gate_V35_2016a__IN_PassAssigned ((uint8_T)2U)
#define gate_V35_2016a__IN_initiatePass ((uint8_T)1U)
#define gate_V35_2016a__IN_openLeftSide ((uint8_T)1U)
#define gate_V35_201_IN_closingLeftSide ((uint8_T)1U)
#define gate_V35_20_IN_MonitoringNumber ((uint8_T)1U)
#define gate_V35_20_IN_closingRightSide ((uint8_T)2U)
#define gate_V35_2_IN_monitorBtnPressed ((uint8_T)3U)
#define gate__IN_PassAssignedPreviously ((uint8_T)2U)

/* Block signals (auto storage) */
B_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_B;

/* Block states (auto storage) */
DW_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_DW;

/* Real-time model */
RT_MODEL_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_M_;
RT_MODEL_gate_V35_2016a_SIM_T *const gate_V35_2016a_SIM_M =
  &gate_V35_2016a_SIM_M_;

/* Forward declaration for local functions */
static void gate_V35_2016a_SIM_closed(const uint8_T *KpCharPressed_prev, const
  boolean_T *RFPressedOut_UINT8_prev, const boolean_T *passSwitch_prev);

/*
 * System initialize for atomic system:
 *    '<S36>/rightSquareWaveDetector'
 *    '<S36>/rightSquareWaveDetector1'
 */
void ga_rightSquareWaveDetector_Init(B_rightSquareWaveDetector_gat_T *localB,
  DW_rightSquareWaveDetector_ga_T *localDW)
{
  localDW->bitsForTID0.is_Running = gate_V35_201_IN_NO_ACTIVE_CHILD;
  localDW->bitsForTID0.is_active_c22_gate_V35_2016a_SI = 0U;
  localDW->bitsForTID0.is_c22_gate_V35_2016a_SIM =
    gate_V35_201_IN_NO_ACTIVE_CHILD;
  localDW->counterHigh = 0U;
  localDW->counterLow = 0U;
  localB->currentValue = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S36>/rightSquareWaveDetector'
 *    '<S36>/rightSquareWaveDetector1'
 */
void gate_V3_rightSquareWaveDetector(boolean_T rtu_CurrentAnalogIn, boolean_T
  rtu_CurrentAnalogInOld, uint8_T rtu_CURRENT_STABLE_TIMER,
  B_rightSquareWaveDetector_gat_T *localB, DW_rightSquareWaveDetector_ga_T
  *localDW)
{
  uint32_T tmp;

  /* Gateway: Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector */
  /* During: Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector */
  if (localDW->bitsForTID0.is_active_c22_gate_V35_2016a_SI == 0U) {
    /* Entry: Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector */
    localDW->bitsForTID0.is_active_c22_gate_V35_2016a_SI = 1U;

    /* Entry Internal: Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector */
    /* Transition: '<S37>:6' */
    localDW->bitsForTID0.is_c22_gate_V35_2016a_SIM = gate_V35_2016a_SIM_IN_Stop;

    /* Entry 'Stop': '<S37>:5' */
    localB->currentValue = 0U;
  } else if (localDW->bitsForTID0.is_c22_gate_V35_2016a_SIM ==
             gate_V35_2016a_SIM_IN_Running) {
    /* During 'Running': '<S37>:13' */
    if ((localDW->counterHigh >= rtu_CURRENT_STABLE_TIMER) ||
        (localDW->counterLow >= rtu_CURRENT_STABLE_TIMER)) {
      /* Transition: '<S37>:16' */
      /* Exit Internal 'Running': '<S37>:13' */
      localDW->bitsForTID0.is_Running = gate_V35_201_IN_NO_ACTIVE_CHILD;
      localDW->bitsForTID0.is_c22_gate_V35_2016a_SIM =
        gate_V35_2016a_SIM_IN_Stop;

      /* Entry 'Stop': '<S37>:5' */
      localB->currentValue = 0U;
    } else if (localDW->bitsForTID0.is_Running == gate_V35_2016a_SIM_IN_High) {
      /* During 'High': '<S37>:7' */
      if (!rtu_CurrentAnalogIn) {
        /* Transition: '<S37>:10' */
        localDW->bitsForTID0.is_Running = gate_V35_2016a_SIM_IN_Low;

        /* Entry 'Low': '<S37>:8' */
        localDW->counterHigh = 0U;
      } else {
        /* Transition: '<S37>:12' */
        tmp = localDW->counterHigh + 1UL;
        if ((int32_T)tmp > 65535L) {
          tmp = 65535UL;
        }

        localDW->counterHigh = (uint16_T)tmp;
        localDW->bitsForTID0.is_Running = gate_V35_2016a_SIM_IN_High;

        /* Entry 'High': '<S37>:7' */
        localDW->counterLow = 0U;
      }
    } else {
      /* During 'Low': '<S37>:8' */
      if (rtu_CurrentAnalogIn) {
        /* Transition: '<S37>:11' */
        localDW->bitsForTID0.is_Running = gate_V35_2016a_SIM_IN_High;

        /* Entry 'High': '<S37>:7' */
        localDW->counterLow = 0U;
      } else {
        /* Transition: '<S37>:14' */
        tmp = localDW->counterLow + 1UL;
        if ((int32_T)tmp > 65535L) {
          tmp = 65535UL;
        }

        localDW->counterLow = (uint16_T)tmp;
        localDW->bitsForTID0.is_Running = gate_V35_2016a_SIM_IN_Low;

        /* Entry 'Low': '<S37>:8' */
        localDW->counterHigh = 0U;
      }
    }
  } else {
    /* During 'Stop': '<S37>:5' */
    if ((rtu_CurrentAnalogInOld && (!rtu_CurrentAnalogIn)) ||
        ((!rtu_CurrentAnalogInOld) && rtu_CurrentAnalogIn)) {
      /* Transition: '<S37>:9' */
      localDW->bitsForTID0.is_c22_gate_V35_2016a_SIM =
        gate_V35_2016a_SIM_IN_Running;

      /* Entry 'Running': '<S37>:13' */
      localDW->counterHigh = 0U;
      localB->currentValue = 1U;

      /* Entry Internal 'Running': '<S37>:13' */
      /* Transition: '<S37>:17' */
      localDW->bitsForTID0.is_Running = gate_V35_2016a_SIM_IN_High;

      /* Entry 'High': '<S37>:7' */
      localDW->counterLow = 0U;
    }
  }
}

/* Function for Chart: '<S23>/GateLogicStatemachine' */
static void gate_V35_2016a_SIM_closed(const uint8_T *KpCharPressed_prev, const
  boolean_T *RFPressedOut_UINT8_prev, const boolean_T *passSwitch_prev)
{
  int16_T tmp;
  uint32_T tmp_0;

  /* During 'closed': '<S34>:32' */
  if ((*passSwitch_prev != gate_V35_2016a_SIM_DW.passSwitch_start) &&
      gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
    /* Transition: '<S34>:35' */
    /* Transition: '<S34>:232' */
    /* Exit Internal 'closed': '<S34>:32' */
    /* Exit Internal 'KpPassHandler': '<S34>:62' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;

    /* Exit Internal 'initTrailPass': '<S34>:97' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
      gate_V35_2016a_SIM_IN_init;

    /* Constant: '<S23>/NO_PASS_ASSIG' */
    /* Entry 'init': '<S34>:22' */
    gate_V35_2016a_SIM_B.passSuccess = gate_V35_2016a_SIM_P.NO_PASS_ASSIG;
    gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = false;
    gate_V35_2016a_SIM_B.bulbPin_BOOL = false;

    /* Constant: '<S23>/CLOSING' */
    gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
    gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;

    /* Constant: '<S23>/INIT' */
    gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.INIT;

    /* Entry Internal 'init': '<S34>:22' */
    /* Transition: '<S34>:2' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_init = gate_V35_2016a_SIM_IN_idle;

    /* Entry 'idle': '<S34>:1' */
    gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = false;
  } else if (gate_V35_2016a_SIM_DW.openingActive ==
             gate_V35_2016a_SIM_P.OPENING_ACTIVE) {
    /* Transition: '<S34>:86' */
    /* Exit Internal 'closed': '<S34>:32' */
    /* Exit Internal 'KpPassHandler': '<S34>:62' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;

    /* Exit Internal 'initTrailPass': '<S34>:97' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
      gate_V35_2016a_SIM_IN_opening;
    gate_V35_2016a_SIM_DW.temporalCounter_i2 = 0UL;

    /* Entry 'opening': '<S34>:183' */
    gate_V35_2016a_SIM_B.bulbPin_BOOL = true;

    /* Constant: '<S23>/OPENING' */
    gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.OPENING;

    /* Entry Internal 'opening': '<S34>:183' */
    /* Transition: '<S34>:189' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
      gate_V35_2016a__IN_openLeftSide;
    gate_V35_2016a_SIM_DW.temporalCounter_i1 = 0U;

    /* Constant: '<S23>/OPENING' */
    /* Entry 'openLeftSide': '<S34>:83' */
    gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.OPENING;

    /* Constant: '<S23>/CLOSED' */
    gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSED;
  } else {
    switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_closed) {
     case gate_V35_2016a_IN_KpPassHandler:
      /* Constant: '<S23>/OPENING_ACTIVE' incorporates:
       *  Constant: '<S23>/PASS_TIMEOUT'
       *  Constant: '<S23>/WRONG_PASSWORD'
       */
      /* During 'KpPassHandler': '<S34>:62' */
      if (gate_V35_2016a_SIM_DW.openingActive ==
          gate_V35_2016a_SIM_P.OPENING_ACTIVE) {
        /* Transition: '<S34>:24' */
        /* Exit Internal 'KpPassHandler': '<S34>:62' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;

        /* Exit Internal 'initTrailPass': '<S34>:97' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a_S_IN_openingGate;
      } else if (gate_V35_2016a_SIM_B.passSuccess ==
                 gate_V35_2016a_SIM_P.WRONG_PASSWORD) {
        /* Transition: '<S34>:28' */
        /* Exit Internal 'KpPassHandler': '<S34>:62' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;

        /* Exit Internal 'initTrailPass': '<S34>:97' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else if (gate_V35_2016a_SIM_DW.temporalCounter_i1 >=
                 gate_V35_2016a_SIM_P.PASS_TIMEOUT) {
        /* Transition: '<S34>:361' */
        /* Exit Internal 'KpPassHandler': '<S34>:62' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;

        /* Exit Internal 'initTrailPass': '<S34>:97' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;

        /* Constant: '<S23>/TIMEOUT' */
        /* passTimer == PASS_TIMEOUT)] */
        gate_V35_2016a_SIM_B.passSuccess = gate_V35_2016a_SIM_P.TIMEOUT;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else {
        tmp_0 = gate_V35_2016a_SIM_DW.passTimer + 1UL;
        if ((int32_T)tmp_0 > 65535L) {
          tmp_0 = 65535UL;
        }

        gate_V35_2016a_SIM_DW.passTimer = (uint16_T)tmp_0;
        switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler) {
         case gate_V35_2016a_SI_IN_btnPressed:
          /* During 'btnPressed': '<S34>:56' */
          if (gate_V35_2016a_SIM_DW.counter_e < 5) {
            /* Transition: '<S34>:49' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
              gate_V35_2_IN_monitorBtnPressed;
          } else {
            if (gate_V35_2016a_SIM_DW.counter_e >= 5) {
              /* Transition: '<S34>:61' */
              gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
                gate_V35_2016a_SI_IN_verifyPass;

              /* Entry Internal 'verifyPass': '<S34>:105' */
              /* Transition: '<S34>:114' */
              if (gate_V35_2016a_SIM_DW.trialPass[0] !=
                  gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[0]) {
                /* Constant: '<S23>/WRONG_PASSWORD' */
                /* Transition: '<S34>:117' */
                /* Transition: '<S34>:130' */
                gate_V35_2016a_SIM_B.passSuccess =
                  gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                /* Transition: '<S34>:166' */
                /* Transition: '<S34>:173' */
                /* Transition: '<S34>:174' */
                /* Transition: '<S34>:176' */
                /* Transition: '<S34>:177' */
                /* Transition: '<S34>:179' */
              } else {
                /* Transition: '<S34>:128' */
                if (gate_V35_2016a_SIM_DW.trialPass[1] !=
                    gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[1]) {
                  /* Constant: '<S23>/WRONG_PASSWORD' */
                  /* Transition: '<S34>:129' */
                  /* Transition: '<S34>:132' */
                  gate_V35_2016a_SIM_B.passSuccess =
                    gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                  /* Transition: '<S34>:173' */
                  /* Transition: '<S34>:174' */
                  /* Transition: '<S34>:176' */
                  /* Transition: '<S34>:177' */
                  /* Transition: '<S34>:179' */
                } else {
                  /* Transition: '<S34>:134' */
                  if (gate_V35_2016a_SIM_DW.trialPass[2] !=
                      gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[2]) {
                    /* Constant: '<S23>/WRONG_PASSWORD' */
                    /* Transition: '<S34>:148' */
                    /* Transition: '<S34>:167' */
                    gate_V35_2016a_SIM_B.passSuccess =
                      gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                    /* Transition: '<S34>:174' */
                    /* Transition: '<S34>:176' */
                    /* Transition: '<S34>:177' */
                    /* Transition: '<S34>:179' */
                  } else {
                    /* Transition: '<S34>:146' */
                    if (gate_V35_2016a_SIM_DW.trialPass[3] !=
                        gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[3]) {
                      /* Constant: '<S23>/WRONG_PASSWORD' */
                      /* Transition: '<S34>:150' */
                      /* Transition: '<S34>:172' */
                      gate_V35_2016a_SIM_B.passSuccess =
                        gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                      /* Transition: '<S34>:176' */
                      /* Transition: '<S34>:177' */
                      /* Transition: '<S34>:179' */
                    } else {
                      /* Transition: '<S34>:154' */
                      if (gate_V35_2016a_SIM_DW.trialPass[4] !=
                          gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[4]) {
                        /* Constant: '<S23>/WRONG_PASSWORD' */
                        /* Transition: '<S34>:155' */
                        /* Transition: '<S34>:175' */
                        gate_V35_2016a_SIM_B.passSuccess =
                          gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                        /* Transition: '<S34>:177' */
                        /* Transition: '<S34>:179' */
                      } else {
                        /* Transition: '<S34>:160' */
                        if (gate_V35_2016a_SIM_DW.trialPass[5] !=
                            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[5]) {
                          /* Constant: '<S23>/WRONG_PASSWORD' */
                          /* Transition: '<S34>:159' */
                          /* Transition: '<S34>:178' */
                          gate_V35_2016a_SIM_B.passSuccess =
                            gate_V35_2016a_SIM_P.WRONG_PASSWORD;

                          /* Transition: '<S34>:179' */
                        } else {
                          /* Constant: '<S23>/PASSWORD_VERIFIED' */
                          /* Transition: '<S34>:163' */
                          gate_V35_2016a_SIM_B.passSuccess =
                            gate_V35_2016a_SIM_P.PASSWORD_VERIFIED;
                        }
                      }
                    }
                  }
                }
              }

              /* Transition: '<S34>:180' */
            }
          }
          break;

         case gate_V35_2016a_IN_initTrailPass:
          /* During 'initTrailPass': '<S34>:97' */
          if (gate_V35_2016a_SIM_DW.initCounter == 5) {
            /* Transition: '<S34>:102' */
            /* Exit Internal 'initTrailPass': '<S34>:97' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
              gate_V35_2_IN_NO_ACTIVE_CHILD_g;
            gate_V35_2016a_SIM_DW.counter_e = 0U;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
              gate_V35_2_IN_monitorBtnPressed;
          } else {
            /* During 'initiatePass': '<S34>:101' */
            if (gate_V35_2016a_SIM_DW.initCounter < 5) {
              /* Transition: '<S34>:99' */
              /* Transition: '<S34>:100' */
              tmp = gate_V35_2016a_SIM_DW.initCounter + 1;
              if (tmp > 255) {
                tmp = 255;
              }

              gate_V35_2016a_SIM_DW.initCounter = (uint8_T)tmp;
              gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
                gate_V35_2016a__IN_initiatePass;

              /* Entry 'initiatePass': '<S34>:101' */
              gate_V35_2016a_SIM_DW.trialPass[gate_V35_2016a_SIM_DW.initCounter]
                = 0U;
            }
          }
          break;

         case gate_V35_2_IN_monitorBtnPressed:
          /* During 'monitorBtnPressed': '<S34>:59' */
          if ((*KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start)
              && (gate_V35_2016a_SIM_B.KeypadLib != 0)) {
            /* Transition: '<S34>:58' */
            /* Transition: '<S34>:236' */
            tmp = gate_V35_2016a_SIM_DW.counter_e + 1;
            if (tmp > 255) {
              tmp = 255;
            }

            gate_V35_2016a_SIM_DW.counter_e = (uint8_T)tmp;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
              gate_V35_2016a_SI_IN_btnPressed;

            /* Entry 'btnPressed': '<S34>:56' */
            gate_V35_2016a_SIM_DW.trialPass[gate_V35_2016a_SIM_DW.counter_e] =
              gate_V35_2016a_SIM_B.KeypadLib;
          }
          break;

         default:
          /* Constant: '<S23>/PASSWORD_VERIFIED' incorporates:
           *  Constant: '<S23>/OPEN_CHAR'
           */
          /* During 'verifyPass': '<S34>:105' */
          if ((*KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start)
              && (gate_V35_2016a_SIM_B.passSuccess ==
                  gate_V35_2016a_SIM_P.PASSWORD_VERIFIED) &&
              ((gate_V35_2016a_SIM_B.KeypadLib == gate_V35_2016a_SIM_P.OPEN_CHAR)
               && (gate_V35_2016a_SIM_B.KeypadLib != 0))) {
            /* Transition: '<S34>:53' */
            /* Transition: '<S34>:239' */
            gate_V35_2016a_SIM_DW.openingActive =
              gate_V35_2016a_SIM_P.OPENING_ACTIVE;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
              gate_V35_2016a_IN_initTrailPass;

            /* Entry 'initTrailPass': '<S34>:97' */
            gate_V35_2016a_SIM_DW.initCounter = 1U;

            /* Entry Internal 'initTrailPass': '<S34>:97' */
            /* Transition: '<S34>:270' */
            /* Transition: '<S34>:100' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
              gate_V35_2016a__IN_initiatePass;

            /* Entry 'initiatePass': '<S34>:101' */
            gate_V35_2016a_SIM_DW.trialPass[gate_V35_2016a_SIM_DW.initCounter] =
              0U;
          }
          break;
        }
      }
      break;

     case gate_V35_2016a__IN_MonitorInput:
      /* During 'MonitorInput': '<S34>:29' */
      if ((*RFPressedOut_UINT8_prev !=
           gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start) &&
          gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) {
        /* Constant: '<S23>/OPENING_ACTIVE' */
        /* Transition: '<S34>:245' */
        gate_V35_2016a_SIM_DW.openingActive =
          gate_V35_2016a_SIM_P.OPENING_ACTIVE;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a_S_IN_openingGate;
      } else {
        if ((*KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start) &&
            ((gate_V35_2016a_SIM_B.KeypadLib != 0) &&
             (gate_V35_2016a_SIM_B.KeypadLib != gate_V35_2016a_SIM_P.OPEN_CHAR) &&
             (gate_V35_2016a_SIM_B.KeypadLib != gate_V35_2016a_SIM_P.CLOSE_CHAR)
             && gate_V35_2016a_SIM_B.passAssignedRAM_BOOL &&
             (!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2))) {
          /* Constant: '<S23>/PASS_INCOMPLETE' */
          /* Transition: '<S34>:26' */
          /* Transition: '<S34>:234' */
          gate_V35_2016a_SIM_B.passSuccess =
            gate_V35_2016a_SIM_P.PASS_INCOMPLETE;
          gate_V35_2016a_SIM_DW.trialPass[0] = gate_V35_2016a_SIM_B.KeypadLib;
          gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
            gate_V35_2016a_IN_KpPassHandler;
          gate_V35_2016a_SIM_DW.temporalCounter_i1 = 0U;

          /* Entry Internal 'KpPassHandler': '<S34>:62' */
          /* Transition: '<S34>:55' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
            gate_V35_2016a_IN_initTrailPass;

          /* Entry 'initTrailPass': '<S34>:97' */
          gate_V35_2016a_SIM_DW.initCounter = 1U;

          /* Entry Internal 'initTrailPass': '<S34>:97' */
          /* Transition: '<S34>:270' */
          /* Transition: '<S34>:100' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
            gate_V35_2016a__IN_initiatePass;

          /* Entry 'initiatePass': '<S34>:101' */
          gate_V35_2016a_SIM_DW.trialPass[gate_V35_2016a_SIM_DW.initCounter] =
            0U;
        }
      }
      break;

     default:
      /* During 'openingGate': '<S34>:23' */
      break;
    }
  }
}

/* Model step function */
void gate_V35_2016a_SIM_step(void)
{
  boolean_T LogicalOperator;
  uint8_T UnitDelay3[6];
  uint8_T KpCharPressed_prev;
  boolean_T RFPressedOut_UINT8_prev;
  boolean_T passSwitch_prev;
  int16_T i;
  uint32_T tmp;

  /* S-Function (Button_Lib): '<S10>/S-Function Builder1' */
  Button_Lib_Outputs_wrapper( &gate_V35_2016a_SIM_B.SFunctionBuilder1_o1,
    &gate_V35_2016a_SIM_B.SFunctionBuilder1_o2 );

  /* S-Function (keypadLib): '<S12>/KeypadLib' */
  keypadLib_Outputs_wrapper( &gate_V35_2016a_SIM_B.KeypadLib );

  /* S-Function (A0PIN_Lib): '<S5>/S-Function Builder4' */
  A0PIN_Lib_Outputs_wrapper( &gate_V35_2016a_SIM_B.rightSpeedRaw_UINT16 );

  /* Chart: '<S36>/rightSquareWaveDetector' incorporates:
   *  Constant: '<S36>/WRONG_PASSWORD'
   *  UnitDelay: '<S36>/Unit Delay'
   */
  gate_V3_rightSquareWaveDetector(gate_V35_2016a_SIM_B.rightSpeedRaw_UINT16,
    gate_V35_2016a_SIM_DW.UnitDelay_DSTATE,
    gate_V35_2016a_SIM_P.CURRENT_STABLE_TIMER,
    &gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector,
    &gate_V35_2016a_SIM_DW.sf_rightSquareWaveDetector);

  /* S-Function (A1PIN_Lib): '<S5>/S-Function Builder3' */
  A1PIN_Lib_Outputs_wrapper( &gate_V35_2016a_SIM_B.leftSpeedRaw_UINT16 );

  /* Chart: '<S36>/rightSquareWaveDetector1' incorporates:
   *  Constant: '<S36>/WRONG_PASSWORD1'
   *  UnitDelay: '<S36>/Unit Delay1'
   */
  gate_V3_rightSquareWaveDetector(gate_V35_2016a_SIM_B.leftSpeedRaw_UINT16,
    gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE,
    gate_V35_2016a_SIM_P.CURRENT_STABLE_TIMER,
    &gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector1,
    &gate_V35_2016a_SIM_DW.sf_rightSquareWaveDetector1);

  /* Logic: '<S36>/Logical Operator' */
  LogicalOperator =
    ((gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector.currentValue != 0) ||
     (gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector1.currentValue != 0));

  /* UnitDelay: '<S3>/Unit Delay3' */
  for (i = 0; i < 6; i++) {
    UnitDelay3[i] = gate_V35_2016a_SIM_B.SFunctionBuilder_o1[i];
  }

  /* End of UnitDelay: '<S3>/Unit Delay3' */

  /* Chart: '<S23>/GateLogicStatemachine' incorporates:
   *  Constant: '<S23>/CLOSED'
   *  Constant: '<S23>/CLOSE_CHAR'
   *  Constant: '<S23>/CLOSE_SIDE_VALUE'
   *  Constant: '<S23>/CLOSING'
   *  Constant: '<S23>/INIT'
   *  Constant: '<S23>/MOVING_TIMER'
   *  Constant: '<S23>/NO_PASS_ASSIG'
   *  Constant: '<S23>/OPEN'
   *  Constant: '<S23>/OPENING'
   *  Constant: '<S23>/OPEN_CHAR'
   *  Constant: '<S23>/OPEN_SIDE_VALUE'
   *  Constant: '<S23>/PASS_ASSIGNED'
   *  Constant: '<S23>/STABLE_TIMER_VALUE'
   *  UnitDelay: '<S3>/Unit Delay2'
   */
  /* Gateway: Gate/Subsystem/B_Variant_KP_RF/GateLogicStatemachine */
  if (gate_V35_2016a_SIM_DW.temporalCounter_i1 < MAX_uint16_T) {
    gate_V35_2016a_SIM_DW.temporalCounter_i1++;
  }

  if (gate_V35_2016a_SIM_DW.temporalCounter_i2 < MAX_uint32_T) {
    gate_V35_2016a_SIM_DW.temporalCounter_i2++;
  }

  KpCharPressed_prev = gate_V35_2016a_SIM_DW.KpCharPressed_start;
  gate_V35_2016a_SIM_DW.KpCharPressed_start = gate_V35_2016a_SIM_B.KeypadLib;
  RFPressedOut_UINT8_prev = gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start;
  gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start =
    gate_V35_2016a_SIM_B.SFunctionBuilder1_o1;
  passSwitch_prev = gate_V35_2016a_SIM_DW.passSwitch_start;
  gate_V35_2016a_SIM_DW.passSwitch_start =
    gate_V35_2016a_SIM_B.SFunctionBuilder1_o2;

  /* During: Gate/Subsystem/B_Variant_KP_RF/GateLogicStatemachine */
  if (gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c20_gate_V35_2016a_SI == 0U) {
    /* Entry: Gate/Subsystem/B_Variant_KP_RF/GateLogicStatemachine */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c20_gate_V35_2016a_SI = 1U;

    /* Entry Internal: Gate/Subsystem/B_Variant_KP_RF/GateLogicStatemachine */
    /* Transition: '<S34>:34' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
      gate_V35_2016a_SIM_IN_init;

    /* Entry 'init': '<S34>:22' */
    gate_V35_2016a_SIM_B.passSuccess = gate_V35_2016a_SIM_P.NO_PASS_ASSIG;
    gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = false;
    gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
    gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
    gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
    gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.INIT;

    /* Entry Internal 'init': '<S34>:22' */
    /* Transition: '<S34>:2' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_init = gate_V35_2016a_SIM_IN_idle;

    /* Entry 'idle': '<S34>:1' */
    gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = false;
  } else {
    switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM) {
     case gate_V35_2016a_SIM_IN_closed:
      gate_V35_2016a_SIM_closed(&KpCharPressed_prev, &RFPressedOut_UINT8_prev,
        &passSwitch_prev);
      break;

     case gate_V35_2016a_SIM_IN_closing:
      /* During 'closing': '<S34>:206' */
      if ((!LogicalOperator) && (gate_V35_2016a_SIM_DW.temporalCounter_i2 >=
           (uint32_T)(gate_V35_2016a_SIM_P.CLOSE_SIDE_VALUE + (real32_T)
                      gate_V35_2016a_SIM_P.STABLE_TIMER_VALUE))) {
        /* Transition: '<S34>:207' */
        /* Exit Internal 'closing': '<S34>:206' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closed;

        /* Entry 'closed': '<S34>:32' */
        gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_DW.openingActive = 0U;
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSED;

        /* Entry Internal 'closed': '<S34>:32' */
        /* Transition: '<S34>:30' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else if ((((RFPressedOut_UINT8_prev !=
                    gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start) &&
                   gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) ||
                  ((gate_V35_2016a_SIM_B.KeypadLib ==
                    gate_V35_2016a_SIM_P.CLOSE_CHAR) && (KpCharPressed_prev !=
                    gate_V35_2016a_SIM_DW.KpCharPressed_start))) &&
                 (gate_V35_2016a_SIM_DW.temporalCounter_i2 >= (uint32_T)
                  (gate_V35_2016a_SIM_P.CLOSE_SIDE_VALUE + (real32_T)
                   gate_V35_2016a_SIM_P.STABLE_TIMER_VALUE))) {
        /* Transition: '<S34>:372' */
        /* Transition: '<S34>:387' */
        /* Exit Internal 'closing': '<S34>:206' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closed;

        /* Entry 'closed': '<S34>:32' */
        gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_DW.openingActive = 0U;
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSED;

        /* Entry Internal 'closed': '<S34>:32' */
        /* Transition: '<S34>:30' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else if (gate_V35_2016a_SIM_DW.temporalCounter_i2 >=
                 gate_V35_2016a_SIM_P.MOVING_TIMER) {
        /* Transition: '<S34>:379' */
        /* Exit Internal 'closing': '<S34>:206' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closed;

        /* Entry 'closed': '<S34>:32' */
        gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_DW.openingActive = 0U;
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSED;

        /* Entry Internal 'closed': '<S34>:32' */
        /* Transition: '<S34>:30' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else if ((gate_V35_2016a_SIM_DW.bitsForTID0.is_closing !=
                  gate_V35_201_IN_closingLeftSide) &&
                 (gate_V35_2016a_SIM_DW.temporalCounter_i1 >= (uint16_T)
                  gate_V35_2016a_SIM_P.CLOSE_SIDE_VALUE)) {
        /* During 'closingRightSide': '<S34>:211' */
        /* Transition: '<S34>:213' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
          gate_V35_201_IN_closingLeftSide;

        /* Entry 'closingLeftSide': '<S34>:212' */
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
      } else {
        /* During 'closingLeftSide': '<S34>:212' */
      }
      break;

     case gate_V35_2016a_SIM_IN_init:
      /* During 'init': '<S34>:22' */
      if (gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady) {
        /* Transition: '<S34>:33' */
        /* Exit Internal 'init': '<S34>:22' */
        /* Exit Internal 'AssignPass': '<S34>:6' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_init =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closed;

        /* Entry 'closed': '<S34>:32' */
        gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_DW.openingActive = 0U;
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSED;

        /* Entry Internal 'closed': '<S34>:32' */
        /* Transition: '<S34>:30' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else if ((RFPressedOut_UINT8_prev !=
                  gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start) &&
                 gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) {
        /* Transition: '<S34>:354' */
        /* Exit Internal 'init': '<S34>:22' */
        /* Exit Internal 'AssignPass': '<S34>:6' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_init =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closed;

        /* Entry 'closed': '<S34>:32' */
        gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
        gate_V35_2016a_SIM_DW.openingActive = 0U;
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSED;

        /* Entry Internal 'closed': '<S34>:32' */
        /* Transition: '<S34>:30' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
          gate_V35_2016a__IN_MonitorInput;

        /* Entry 'MonitorInput': '<S34>:29' */
        gate_V35_2016a_SIM_DW.passTimer = 0U;
      } else {
        switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_init) {
         case gate_V35_2016a_SI_IN_AssignPass:
          /* During 'AssignPass': '<S34>:6' */
          if (!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
            /* Transition: '<S34>:9' */
            /* Exit Internal 'AssignPass': '<S34>:6' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
              gate_V35_2_IN_NO_ACTIVE_CHILD_g;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_init =
              gate_V35_2016a_SIM_IN_idle;

            /* Entry 'idle': '<S34>:1' */
            gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = false;
          } else {
            switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass) {
             case gate_V35_20_IN_MonitoringNumber:
              /* During 'MonitoringNumber': '<S34>:3' */
              if ((KpCharPressed_prev !=
                   gate_V35_2016a_SIM_DW.KpCharPressed_start) &&
                  (gate_V35_2016a_SIM_B.KeypadLib != 0)) {
                /* Transition: '<S34>:14' */
                /* Transition: '<S34>:230' */
                gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
                  gate_V35_2016a_SIM_IN_addToPass;

                /* Entry 'addToPass': '<S34>:4' */
                gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[gate_V35_2016a_SIM_DW.counter_e]
                  = gate_V35_2016a_SIM_B.KeypadLib;
              } else {
                if (gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) {
                  /* Transition: '<S34>:20' */
                  gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
                    gate_V35_2016a__IN_PassAssigned;

                  /* Entry 'PassAssigned': '<S34>:5' */
                  gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = true;
                }
              }
              break;

             case gate_V35_2016a__IN_PassAssigned:
              /* During 'PassAssigned': '<S34>:5' */
              break;

             default:
              /* During 'addToPass': '<S34>:4' */
              if (gate_V35_2016a_SIM_DW.counter_e < 5) {
                /* Transition: '<S34>:15' */
                i = gate_V35_2016a_SIM_DW.counter_e + 1;
                if (i > 255) {
                  i = 255;
                }

                gate_V35_2016a_SIM_DW.counter_e = (uint8_T)i;
                gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
                  gate_V35_20_IN_MonitoringNumber;
              } else {
                if (gate_V35_2016a_SIM_DW.counter_e == 5) {
                  /* Transition: '<S34>:17' */
                  gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = true;
                  gate_V35_2016a_SIM_B.passSuccess =
                    gate_V35_2016a_SIM_P.PASS_ASSIGNED;
                  gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
                    gate_V35_2016a__IN_PassAssigned;

                  /* Entry 'PassAssigned': '<S34>:5' */
                  gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = true;
                }
              }
              break;
            }
          }
          break;

         case gate__IN_PassAssignedPreviously:
          /* During 'PassAssignedPreviously': '<S34>:366' */
          break;

         default:
          /* During 'idle': '<S34>:1' */
          if (gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
            /* Transition: '<S34>:8' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_init =
              gate_V35_2016a_SI_IN_AssignPass;

            /* Entry 'AssignPass': '<S34>:6' */
            gate_V35_2016a_SIM_DW.counter_e = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[0] = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[1] = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[2] = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[3] = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[4] = 0U;
            gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[5] = 0U;

            /* Entry Internal 'AssignPass': '<S34>:6' */
            /* Transition: '<S34>:7' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
              gate_V35_20_IN_MonitoringNumber;
          } else {
            if (gate_V35_2016a_SIM_B.SFunctionBuilder_o5) {
              /* Transition: '<S34>:365' */
              gate_V35_2016a_SIM_DW.bitsForTID0.is_init =
                gate__IN_PassAssignedPreviously;

              /* Entry 'PassAssignedPreviously': '<S34>:366' */
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[0] = UnitDelay3[0];
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[1] = UnitDelay3[1];
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[2] = UnitDelay3[2];
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[3] = UnitDelay3[3];
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[4] = UnitDelay3[4];
              gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[5] = UnitDelay3[5];
              gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = true;
              gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = true;
            }
          }
          break;
        }
      }
      break;

     case gate_V35_2016a_SIM_IN_open:
      /* During 'open': '<S34>:197' */
      if (gate_V35_2016a_SIM_DW.closing_active == 1) {
        /* Transition: '<S34>:198' */
        /* Exit Internal 'open': '<S34>:197' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_closing;
        gate_V35_2016a_SIM_DW.temporalCounter_i2 = 0UL;

        /* Entry 'closing': '<S34>:206' */
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.CLOSING;

        /* Entry Internal 'closing': '<S34>:206' */
        /* Transition: '<S34>:223' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
          gate_V35_20_IN_closingRightSide;
        gate_V35_2016a_SIM_DW.temporalCounter_i1 = 0U;

        /* Entry 'closingRightSide': '<S34>:211' */
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.CLOSING;
      } else if (gate_V35_2016a_SIM_DW.bitsForTID0.is_open !=
                 gate_V35_2016a_SIM_IN_closing_g) {
        /* During 'gateOpen': '<S34>:84' */
        if ((KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start) &&
            (gate_V35_2016a_SIM_B.KeypadLib == gate_V35_2016a_SIM_P.CLOSE_CHAR))
        {
          /* Transition: '<S34>:221' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
            gate_V35_2016a_SIM_IN_closing_g;

          /* Entry 'closing': '<S34>:196' */
          gate_V35_2016a_SIM_DW.closing_active = 1U;
        } else {
          if ((RFPressedOut_UINT8_prev !=
               gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start) &&
              gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) {
            /* Transition: '<S34>:203' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
              gate_V35_2016a_SIM_IN_closing_g;

            /* Entry 'closing': '<S34>:196' */
            gate_V35_2016a_SIM_DW.closing_active = 1U;
          }
        }
      } else {
        /* During 'closing': '<S34>:196' */
      }
      break;

     default:
      /* During 'opening': '<S34>:183' */
      tmp = (uint32_T)gate_V35_2016a_SIM_P.OPEN_SIDE_VALUE +
        gate_V35_2016a_SIM_P.STABLE_TIMER_VALUE;
      if ((int32_T)tmp > 65535L) {
        tmp = 65535UL;
      }

      if ((((RFPressedOut_UINT8_prev !=
             gate_V35_2016a_SIM_DW.RFPressedOut_UINT8_start) &&
            gate_V35_2016a_SIM_B.SFunctionBuilder1_o1) ||
           ((gate_V35_2016a_SIM_B.KeypadLib == gate_V35_2016a_SIM_P.OPEN_CHAR) &&
            (KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start))) &&
          (gate_V35_2016a_SIM_DW.temporalCounter_i2 >= tmp)) {
        /* Transition: '<S34>:370' */
        /* Transition: '<S34>:385' */
        /* Exit Internal 'opening': '<S34>:183' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_open;

        /* Entry 'open': '<S34>:197' */
        gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.OPEN;

        /* Entry Internal 'open': '<S34>:197' */
        /* Transition: '<S34>:224' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
          gate_V35_2016a_SIM_IN_gateOpen;

        /* Entry 'gateOpen': '<S34>:84' */
        gate_V35_2016a_SIM_DW.closing_active = 0U;
        gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.OPEN;
        gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.OPEN;
      } else {
        tmp = (uint32_T)gate_V35_2016a_SIM_P.OPEN_SIDE_VALUE +
          gate_V35_2016a_SIM_P.STABLE_TIMER_VALUE;
        if ((int32_T)tmp > 65535L) {
          tmp = 65535UL;
        }

        if ((!LogicalOperator) && (gate_V35_2016a_SIM_DW.temporalCounter_i2 >=
             tmp)) {
          /* Transition: '<S34>:184' */
          /* Exit Internal 'opening': '<S34>:183' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
            gate_V35_2_IN_NO_ACTIVE_CHILD_g;
          gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
            gate_V35_2016a_SIM_IN_open;

          /* Entry 'open': '<S34>:197' */
          gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.OPEN;

          /* Entry Internal 'open': '<S34>:197' */
          /* Transition: '<S34>:224' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
            gate_V35_2016a_SIM_IN_gateOpen;

          /* Entry 'gateOpen': '<S34>:84' */
          gate_V35_2016a_SIM_DW.closing_active = 0U;
          gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.OPEN;
          gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.OPEN;
        } else if (gate_V35_2016a_SIM_DW.temporalCounter_i2 >=
                   gate_V35_2016a_SIM_P.MOVING_TIMER) {
          /* Transition: '<S34>:378' */
          /* Exit Internal 'opening': '<S34>:183' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
            gate_V35_2_IN_NO_ACTIVE_CHILD_g;
          gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
            gate_V35_2016a_SIM_IN_open;

          /* Entry 'open': '<S34>:197' */
          gate_V35_2016a_SIM_B.gateState = gate_V35_2016a_SIM_P.OPEN;

          /* Entry Internal 'open': '<S34>:197' */
          /* Transition: '<S34>:224' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_open =
            gate_V35_2016a_SIM_IN_gateOpen;

          /* Entry 'gateOpen': '<S34>:84' */
          gate_V35_2016a_SIM_DW.closing_active = 0U;
          gate_V35_2016a_SIM_B.leftMotor = gate_V35_2016a_SIM_P.OPEN;
          gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.OPEN;
        } else if ((gate_V35_2016a_SIM_DW.bitsForTID0.is_opening ==
                    gate_V35_2016a__IN_openLeftSide) &&
                   (gate_V35_2016a_SIM_DW.temporalCounter_i1 >=
                    gate_V35_2016a_SIM_P.OPEN_SIDE_VALUE)) {
          /* During 'openLeftSide': '<S34>:83' */
          /* Transition: '<S34>:188' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
            gate_V35_2016a_IN_openRightSide;

          /* Entry 'openRightSide': '<S34>:182' */
          gate_V35_2016a_SIM_B.rightMotor = gate_V35_2016a_SIM_P.OPENING;
        } else {
          /* During 'openRightSide': '<S34>:182' */
        }
      }
      break;
    }
  }

  /* End of Chart: '<S23>/GateLogicStatemachine' */

  /* Chart: '<S26>/LedHandler' incorporates:
   *  Constant: '<S26>/CLOSED'
   *  Constant: '<S26>/CLOSE_CHAR'
   *  Constant: '<S26>/CLOSING'
   *  Constant: '<S26>/INIT'
   *  Constant: '<S26>/NO_PASS_ASSIG'
   *  Constant: '<S26>/OPEN'
   *  Constant: '<S26>/OPENING'
   *  Constant: '<S26>/OPEN_CHAR'
   *  Constant: '<S26>/PASSWORD_VERIFIED'
   *  Constant: '<S26>/TIMEOUT'
   *  Constant: '<S26>/WRONG_PASSWORD'
   */
  /* Gateway: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler */
  LogicalOperator = gate_V35_2016a_SIM_DW.PassSw_start;
  gate_V35_2016a_SIM_DW.PassSw_start = gate_V35_2016a_SIM_B.SFunctionBuilder1_o2;
  KpCharPressed_prev = gate_V35_2016a_SIM_DW.KpCharPressed_start_g;
  gate_V35_2016a_SIM_DW.KpCharPressed_start_g = gate_V35_2016a_SIM_B.KeypadLib;

  /* During: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler */
  if (gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c16_gate_V35_2016a_SI == 0U) {
    /* Entry: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c16_gate_V35_2016a_SI = 1U;

    /* Entry Internal: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler */
    /* Transition: '<S29>:53' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
      gate_V35_2016a_SIM_IN_Idle_g;

    /* Entry 'Idle': '<S29>:47' */
    gate_V35_2016a_SIM_DW.counter = 0U;
    gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
    gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
    gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
  } else {
    switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM) {
     case gate_V35_2016a_IN_AssigningPass:
      /* During 'AssigningPass': '<S29>:75' */
      if (gate_V35_2016a_SIM_DW.counter >= 4900U) {
        /* Transition: '<S29>:59' */
        /* Exit Internal 'AssigningPass': '<S29>:75' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_Idle_g;

        /* Entry 'Idle': '<S29>:47' */
        gate_V35_2016a_SIM_DW.counter = 0U;
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else if ((gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPENING)
                 || (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPEN)
                 || (gate_V35_2016a_SIM_B.gateState ==
                     gate_V35_2016a_SIM_P.CLOSING)) {
        /* Transition: '<S29>:84' */
        /* Exit Internal 'AssigningPass': '<S29>:75' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_GateOn;

        /* Entry 'GateOn': '<S29>:83' */
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = true;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else if ((LogicalOperator != gate_V35_2016a_SIM_DW.PassSw_start) &&
                 gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
        /* Transition: '<S29>:116' */
        /* Exit Internal 'AssigningPass': '<S29>:75' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_IN_AssigningPass;

        /* Entry Internal 'AssigningPass': '<S29>:75' */
        /* Transition: '<S29>:76' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
          gate_V35_2016a_SIM_IN_Start;

        /* Entry 'Start': '<S29>:46' */
        gate_V35_2016a_SIM_DW.counter = 0U;
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = true;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else {
        switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass) {
         case gate_V35_2016a_SIM_IN_Start:
          /* During 'Start': '<S29>:46' */
          if (gate_V35_2016a_SIM_B.passAssignedRAM_BOOL) {
            /* Transition: '<S29>:50' */
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = true;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
              gate_V35_IN_correctPassAssigned;
          } else {
            if ((!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) &&
                (!gate_V35_2016a_SIM_B.passAssignedRAM_BOOL)) {
              /* Transition: '<S29>:52' */
              gate_V35_2016a_SIM_B.redLedPin_BOOL = true;
              gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
              gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
                gate_V_IN_incorrectPassAssigned;
            }
          }
          break;

         case gate_V35_IN_correctPassAssigned:
          /* During 'correctPassAssigned': '<S29>:49' */
          if ((LogicalOperator != gate_V35_2016a_SIM_DW.PassSw_start) &&
              (!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2)) {
            /* Transition: '<S29>:57' */
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
              gate_V35_IN_correctPassAssigned;
          } else {
            tmp = gate_V35_2016a_SIM_DW.counter + 1UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            gate_V35_2016a_SIM_DW.counter = (uint16_T)tmp;
          }
          break;

         default:
          /* During 'incorrectPassAssigned': '<S29>:51' */
          tmp = gate_V35_2016a_SIM_DW.counter + 1UL;
          if ((int32_T)tmp > 65535L) {
            tmp = 65535UL;
          }

          gate_V35_2016a_SIM_DW.counter = (uint16_T)tmp;
          break;
        }
      }
      break;

     case gate_V35_2016a__IN_EnteringPass:
      /* During 'EnteringPass': '<S29>:88' */
      if ((gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPENING) ||
          (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPEN) ||
          (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.CLOSING)) {
        /* Transition: '<S29>:95' */
        /* Exit Internal 'EnteringPass': '<S29>:88' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_GateOn;

        /* Entry 'GateOn': '<S29>:83' */
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = true;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else if (gate_V35_2016a_SIM_B.passSuccess ==
                 gate_V35_2016a_SIM_P.NO_PASS_ASSIG) {
        /* Transition: '<S29>:96' */
        /* Exit Internal 'EnteringPass': '<S29>:88' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
          gate_V35_2_IN_NO_ACTIVE_CHILD_g;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_Idle_g;

        /* Entry 'Idle': '<S29>:47' */
        gate_V35_2016a_SIM_DW.counter = 0U;
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else {
        switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass) {
         case gate_V35_2016a_IN_IncorrectPass:
          /* During 'IncorrectPass': '<S29>:87' */
          /* Transition: '<S29>:98' */
          if (gate_V35_2016a_SIM_DW.counter >= 4800U) {
            /* Transition: '<S29>:114' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2_IN_NO_ACTIVE_CHILD_g;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
              gate_V35_2016a_SIM_IN_Idle_g;

            /* Entry 'Idle': '<S29>:47' */
            gate_V35_2016a_SIM_DW.counter = 0U;
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
          } else if ((KpCharPressed_prev !=
                      gate_V35_2016a_SIM_DW.KpCharPressed_start_g) &&
                     (gate_V35_2016a_SIM_B.KeypadLib != 0) &&
                     (gate_V35_2016a_SIM_B.KeypadLib !=
                      gate_V35_2016a_SIM_P.CLOSE_CHAR) &&
                     (gate_V35_2016a_SIM_B.KeypadLib !=
                      gate_V35_2016a_SIM_P.OPEN_CHAR) &&
                     gate_V35_2016a_SIM_B.passAssignedRAM_BOOL &&
                     (gate_V35_2016a_SIM_B.gateState !=
                      gate_V35_2016a_SIM_P.INIT)) {
            /* Transition: '<S29>:92' */
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = true;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
              gate_V35_2016a__IN_EnteringPass;

            /* Entry 'EnteringPass': '<S29>:88' */
            gate_V35_2016a_SIM_DW.counter = 0U;

            /* Entry Internal 'EnteringPass': '<S29>:88' */
            /* Transition: '<S29>:91' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2016a_SIM_IN_Start_l;
          } else {
            tmp = gate_V35_2016a_SIM_DW.counter + 1UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            gate_V35_2016a_SIM_DW.counter = (uint16_T)tmp;
          }
          break;

         case gate_V35_2016a_SIM_IN_Start_l:
          /* During 'Start': '<S29>:85' */
          if (gate_V35_2016a_SIM_B.passSuccess ==
              gate_V35_2016a_SIM_P.PASSWORD_VERIFIED) {
            /* Transition: '<S29>:89' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2016a_S_IN_correctPass;

            /* Entry 'correctPass': '<S29>:86' */
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = true;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
          } else {
            if ((gate_V35_2016a_SIM_B.passSuccess ==
                 gate_V35_2016a_SIM_P.TIMEOUT) ||
                (gate_V35_2016a_SIM_B.passSuccess ==
                 gate_V35_2016a_SIM_P.WRONG_PASSWORD)) {
              /* Transition: '<S29>:90' */
              gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
                gate_V35_2016a_IN_IncorrectPass;

              /* Entry 'IncorrectPass': '<S29>:87' */
              gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
              gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
              gate_V35_2016a_SIM_B.redLedPin_BOOL = true;
            }
          }
          break;

         default:
          /* During 'correctPass': '<S29>:86' */
          /* Transition: '<S29>:102' */
          if (gate_V35_2016a_SIM_DW.counter >= 4800U) {
            /* Transition: '<S29>:114' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2_IN_NO_ACTIVE_CHILD_g;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
              gate_V35_2016a_SIM_IN_Idle_g;

            /* Entry 'Idle': '<S29>:47' */
            gate_V35_2016a_SIM_DW.counter = 0U;
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
          } else if ((KpCharPressed_prev !=
                      gate_V35_2016a_SIM_DW.KpCharPressed_start_g) &&
                     (gate_V35_2016a_SIM_B.KeypadLib != 0) &&
                     (gate_V35_2016a_SIM_B.KeypadLib !=
                      gate_V35_2016a_SIM_P.CLOSE_CHAR) &&
                     (gate_V35_2016a_SIM_B.KeypadLib !=
                      gate_V35_2016a_SIM_P.OPEN_CHAR) &&
                     gate_V35_2016a_SIM_B.passAssignedRAM_BOOL &&
                     (gate_V35_2016a_SIM_B.gateState !=
                      gate_V35_2016a_SIM_P.INIT)) {
            /* Transition: '<S29>:92' */
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = true;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
              gate_V35_2016a__IN_EnteringPass;

            /* Entry 'EnteringPass': '<S29>:88' */
            gate_V35_2016a_SIM_DW.counter = 0U;

            /* Entry Internal 'EnteringPass': '<S29>:88' */
            /* Transition: '<S29>:91' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2016a_SIM_IN_Start_l;
          } else {
            tmp = gate_V35_2016a_SIM_DW.counter + 1UL;
            if ((int32_T)tmp > 65535L) {
              tmp = 65535UL;
            }

            gate_V35_2016a_SIM_DW.counter = (uint16_T)tmp;
          }
          break;
        }
      }
      break;

     case gate_V35_2016a_SIM_IN_GateOn:
      /* During 'GateOn': '<S29>:83' */
      if (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.CLOSED) {
        /* Transition: '<S29>:94' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_Idle_g;

        /* Entry 'Idle': '<S29>:47' */
        gate_V35_2016a_SIM_DW.counter = 0U;
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      }
      break;

     default:
      /* During 'Idle': '<S29>:47' */
      if (gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
        /* Transition: '<S29>:48' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_IN_AssigningPass;

        /* Entry Internal 'AssigningPass': '<S29>:75' */
        /* Transition: '<S29>:76' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
          gate_V35_2016a_SIM_IN_Start;

        /* Entry 'Start': '<S29>:46' */
        gate_V35_2016a_SIM_DW.counter = 0U;
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = true;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else if ((gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPENING)
                 || (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPEN)
                 || (gate_V35_2016a_SIM_B.gateState ==
                     gate_V35_2016a_SIM_P.CLOSING)) {
        /* Transition: '<S29>:101' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_GateOn;

        /* Entry 'GateOn': '<S29>:83' */
        gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
        gate_V35_2016a_SIM_B.greenLedPin_BOOL = true;
        gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
      } else {
        /* Transition: '<S29>:115' */
        if (gate_V35_2016a_SIM_DW.counter >= 4800U) {
          /* Transition: '<S29>:114' */
          gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
            gate_V35_2016a_SIM_IN_Idle_g;

          /* Entry 'Idle': '<S29>:47' */
          gate_V35_2016a_SIM_DW.counter = 0U;
          gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;
          gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
          gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
        } else {
          if ((KpCharPressed_prev != gate_V35_2016a_SIM_DW.KpCharPressed_start_g)
              && (gate_V35_2016a_SIM_B.KeypadLib != 0) &&
              (gate_V35_2016a_SIM_B.KeypadLib != gate_V35_2016a_SIM_P.CLOSE_CHAR)
              && (gate_V35_2016a_SIM_B.KeypadLib !=
                  gate_V35_2016a_SIM_P.OPEN_CHAR) &&
              gate_V35_2016a_SIM_B.passAssignedRAM_BOOL &&
              (gate_V35_2016a_SIM_B.gateState != gate_V35_2016a_SIM_P.INIT)) {
            /* Transition: '<S29>:92' */
            gate_V35_2016a_SIM_B.yellowLedPin_BOOL = true;
            gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
            gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
            gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
              gate_V35_2016a__IN_EnteringPass;

            /* Entry 'EnteringPass': '<S29>:88' */
            gate_V35_2016a_SIM_DW.counter = 0U;

            /* Entry Internal 'EnteringPass': '<S29>:88' */
            /* Transition: '<S29>:91' */
            gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
              gate_V35_2016a_SIM_IN_Start_l;
          }
        }
      }
      break;
    }
  }

  /* End of Chart: '<S26>/LedHandler' */

  /* S-Function (arduinodigitaloutput_sfcn): '<S44>/Digital Output' incorporates:
   *  DataTypeConversion: '<S44>/Data Type Conversion'
   */
  MW_digitalWrite(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber, (uint8_T)
                  gate_V35_2016a_SIM_B.greenLedPin_BOOL);

  /* S-Function (arduinodigitaloutput_sfcn): '<S43>/Digital Output' incorporates:
   *  DataTypeConversion: '<S43>/Data Type Conversion'
   */
  MW_digitalWrite(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber_m, (uint8_T)
                  gate_V35_2016a_SIM_B.redLedPin_BOOL);

  /* S-Function (arduinodigitaloutput_sfcn): '<S45>/Digital Output' incorporates:
   *  DataTypeConversion: '<S45>/Data Type Conversion'
   */
  MW_digitalWrite(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber_e, (uint8_T)
                  gate_V35_2016a_SIM_B.yellowLedPin_BOOL);

  /* Chart: '<S27>/MotorsHandler' incorporates:
   *  Constant: '<S27>/CLOSED'
   *  Constant: '<S27>/CLOSING'
   *  Constant: '<S27>/OPEN'
   *  Constant: '<S27>/OPENING'
   *  Constant: '<S27>/OPENING1'
   */
  /* Gateway: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler */
  /* During: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler */
  /* Entry Internal: Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler */
  /* Transition: '<S31>:197' */
  /*  updating motor Pins Switch case  */
  if ((gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.OPENING) &&
      ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.CLOSED) ||
       (gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.OPEN))) {
    /* Transition: '<S31>:165' */
    /* Transition: '<S31>:166' */
    gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = true;
    gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
    gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

    /* Transition: '<S31>:161' */
    /* Transition: '<S31>:174' */
    /* Transition: '<S31>:190' */
    /* Transition: '<S31>:172' */
    /* Transition: '<S31>:151' */
    /* Transition: '<S31>:180' */
    /* Transition: '<S31>:198' */
    /* Transition: '<S31>:147' */
  } else {
    /* Transition: '<S31>:146' */
    if ((gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.CLOSING) &&
        ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.CLOSED) ||
         (gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.OPEN))) {
      /* Transition: '<S31>:183' */
      /* Transition: '<S31>:170' */
      gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
      gate_V35_2016a_SIM_B.ComMotorPin_BOOL = false;
      gate_V35_2016a_SIM_B.RightMotorPin_BOOL = true;

      /* Transition: '<S31>:174' */
      /* Transition: '<S31>:190' */
      /* Transition: '<S31>:172' */
      /* Transition: '<S31>:151' */
      /* Transition: '<S31>:180' */
      /* Transition: '<S31>:198' */
      /* Transition: '<S31>:147' */
    } else {
      /* Transition: '<S31>:176' */
      if ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.CLOSING) &&
          ((gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.CLOSED) ||
           (gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.OPEN))) {
        /* Transition: '<S31>:169' */
        /* Transition: '<S31>:158' */
        gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = true;
        gate_V35_2016a_SIM_B.ComMotorPin_BOOL = false;
        gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

        /* Transition: '<S31>:190' */
        /* Transition: '<S31>:172' */
        /* Transition: '<S31>:151' */
        /* Transition: '<S31>:180' */
        /* Transition: '<S31>:198' */
        /* Transition: '<S31>:147' */
      } else {
        /* Transition: '<S31>:204' */
        if ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.OPENING) &&
            ((gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.CLOSED) ||
             (gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.OPEN))) {
          /* Transition: '<S31>:149' */
          /* Transition: '<S31>:196' */
          gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
          gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
          gate_V35_2016a_SIM_B.RightMotorPin_BOOL = true;

          /* Transition: '<S31>:172' */
          /* Transition: '<S31>:151' */
          /* Transition: '<S31>:180' */
          /* Transition: '<S31>:198' */
          /* Transition: '<S31>:147' */
        } else {
          /* Transition: '<S31>:145' */
          if ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.OPENING) &&
              (gate_V35_2016a_SIM_B.leftMotor == gate_V35_2016a_SIM_P.OPENING))
          {
            /* Transition: '<S31>:201' */
            /* Transition: '<S31>:160' */
            gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = true;
            gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
            gate_V35_2016a_SIM_B.RightMotorPin_BOOL = true;

            /* Transition: '<S31>:151' */
            /* Transition: '<S31>:180' */
            /* Transition: '<S31>:198' */
            /* Transition: '<S31>:147' */
          } else {
            /* Transition: '<S31>:152' */
            if ((gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.CLOSING)
                && (gate_V35_2016a_SIM_B.leftMotor ==
                    gate_V35_2016a_SIM_P.CLOSING)) {
              /* Transition: '<S31>:156' */
              /* Transition: '<S31>:203' */
              gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
              gate_V35_2016a_SIM_B.ComMotorPin_BOOL = false;
              gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

              /* Transition: '<S31>:180' */
              /* Transition: '<S31>:198' */
              /* Transition: '<S31>:147' */
            } else {
              /* Transition: '<S31>:175' */
              if (((gate_V35_2016a_SIM_B.rightMotor ==
                    gate_V35_2016a_SIM_P.CLOSED) ||
                   (gate_V35_2016a_SIM_B.rightMotor == gate_V35_2016a_SIM_P.OPEN))
                  && ((gate_V35_2016a_SIM_B.leftMotor ==
                       gate_V35_2016a_SIM_P.CLOSED) ||
                      (gate_V35_2016a_SIM_B.leftMotor ==
                       gate_V35_2016a_SIM_P.OPEN))) {
                /* Transition: '<S31>:185' */
                /* Transition: '<S31>:182' */
                gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
                gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
                gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

                /* Transition: '<S31>:198' */
                /* Transition: '<S31>:147' */
              } else {
                /* Transition: '<S31>:154' */
                if ((gate_V35_2016a_SIM_B.gateState ==
                     gate_V35_2016a_SIM_P.CLOSED) ||
                    (gate_V35_2016a_SIM_B.gateState == gate_V35_2016a_SIM_P.OPEN)
                    || (gate_V35_2016a_SIM_B.gateState ==
                        gate_V35_2016a_SIM_P.INIT)) {
                  /* Transition: '<S31>:202' */
                  /* Transition: '<S31>:168' */
                  gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
                  gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
                  gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

                  /* Transition: '<S31>:147' */
                } else {
                  /* Transition: '<S31>:199' */
                }
              }
            }
          }
        }
      }
    }
  }

  /* End of Chart: '<S27>/MotorsHandler' */
  /* Transition: '<S31>:191' */

  /* S-Function (A3PIN_Lib): '<S41>/S-Function Builder5' */
  A3PIN_Lib_Outputs_wrapper(&gate_V35_2016a_SIM_B.LeftMotorPin_BOOL );

  /* S-Function (A4PIN_Lib): '<S41>/S-Function Builder3' */
  A4PIN_Lib_Outputs_wrapper(&gate_V35_2016a_SIM_B.ComMotorPin_BOOL );

  /* S-Function (A5PIN_Lib): '<S41>/S-Function Builder4' */
  A5PIN_Lib_Outputs_wrapper(&gate_V35_2016a_SIM_B.RightMotorPin_BOOL );

  /* S-Function (A2PIN_Lib): '<S41>/S-Function Builder1' */
  A2PIN_Lib_Outputs_wrapper(&gate_V35_2016a_SIM_B.bulbPin_BOOL );

  /* Chart: '<S11>/EEPROM_Control' incorporates:
   *  UnitDelay: '<S11>/Unit Delay'
   *  UnitDelay: '<S11>/Unit Delay1'
   */
  /* Gateway: Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_Control */
  LogicalOperator = gate_V35_2016a_SIM_DW.passSw_start;
  gate_V35_2016a_SIM_DW.passSw_start = gate_V35_2016a_SIM_B.SFunctionBuilder1_o2;

  /* During: Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_Control */
  if (gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c7_gate_V35_2016a_SIM == 0U) {
    /* Entry: Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_Control */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c7_gate_V35_2016a_SIM = 1U;

    /* Entry Internal: Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_Control */
    /* Transition: '<S14>:5' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
      gate_V35_2016a_SIM_IN_Read;

    /* Entry 'Read': '<S14>:8' */
    gate_V35_2016a_SIM_B.readReq = false;
  } else {
    switch (gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM) {
     case gate_V35_2016a_SIM_IN_Idle:
      /* During 'Idle': '<S14>:21' */
      if ((LogicalOperator != gate_V35_2016a_SIM_DW.passSw_start) &&
          gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) {
        /* Transition: '<S14>:26' */
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_clear;

        /* Entry 'clear': '<S14>:7' */
        gate_V35_2016a_SIM_B.clearReq = true;
      }
      break;

     case gate_V35_2016a_SIM_IN_Read:
      /* During 'Read': '<S14>:8' */
      /* Transition: '<S14>:24' */
      gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
        gate_V35_2016a_SIM_IN_sendData;

      /* Entry 'sendData': '<S14>:20' */
      gate_V35_2016a_SIM_B.readReq = true;
      break;

     case gate_V35_2016a_SIM_IN_clear:
      /* During 'clear': '<S14>:7' */
      if ((LogicalOperator != gate_V35_2016a_SIM_DW.passSw_start) &&
          (!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) &&
          gate_V35_2016a_SIM_B.passAssignedRAM_BOOL) {
        /* Transition: '<S14>:27' */
        gate_V35_2016a_SIM_B.clearReq = false;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_write;

        /* Entry 'write': '<S14>:6' */
        gate_V35_2016a_SIM_B.writeReq = true;
      } else {
        if ((LogicalOperator != gate_V35_2016a_SIM_DW.passSw_start) &&
            (!gate_V35_2016a_SIM_B.SFunctionBuilder1_o2) &&
            (!gate_V35_2016a_SIM_B.passAssignedRAM_BOOL)) {
          /* Transition: '<S14>:29' */
          gate_V35_2016a_SIM_B.clearReq = false;
          gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
            gate_V35_2016a_SIM_IN_Idle;
        }
      }
      break;

     case gate_V35_2016a_SIM_IN_sendData:
      /* During 'sendData': '<S14>:20' */
      if (gate_V35_2016a_SIM_B.SFunctionBuilder_o2) {
        /* Transition: '<S14>:25' */
        gate_V35_2016a_SIM_B.readReq = false;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_Idle;
      }
      break;

     default:
      /* During 'write': '<S14>:6' */
      if (gate_V35_2016a_SIM_B.SFunctionBuilder_o3) {
        /* Transition: '<S14>:28' */
        gate_V35_2016a_SIM_B.writeReq = false;
        gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
          gate_V35_2016a_SIM_IN_Read;

        /* Entry 'Read': '<S14>:8' */
        gate_V35_2016a_SIM_B.readReq = false;
      }
      break;
    }
  }

  /* End of Chart: '<S11>/EEPROM_Control' */

  /* Outputs for Atomic SubSystem: '<S11>/EEPROM_UPDATE' */
  /* UnitDelay: '<S15>/Unit Delay' */
  gate_V35_2016a_SIM_B.UnitDelay = gate_V35_2016a_SIM_DW.UnitDelay_DSTATE_e;

  /* UnitDelay: '<S15>/Unit Delay1' */
  gate_V35_2016a_SIM_B.UnitDelay1 = gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE_l;

  /* UnitDelay: '<S15>/Unit Delay2' */
  gate_V35_2016a_SIM_B.UnitDelay2_a = gate_V35_2016a_SIM_DW.UnitDelay2_DSTATE_e;

  /* S-Function (myEEPROM_Handler): '<S15>/S-Function Builder' */
  myEEPROM_Handler_Outputs_wrapper(&gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[0],
    &gate_V35_2016a_SIM_B.readReq, &gate_V35_2016a_SIM_B.UnitDelay,
    &gate_V35_2016a_SIM_B.clearReq, &gate_V35_2016a_SIM_B.UnitDelay1,
    &gate_V35_2016a_SIM_B.writeReq, &gate_V35_2016a_SIM_B.UnitDelay2_a,
    &gate_V35_2016a_SIM_B.passAssignedRAM_BOOL,
    &gate_V35_2016a_SIM_B.SFunctionBuilder_o1[0],
    &gate_V35_2016a_SIM_B.SFunctionBuilder_o2,
    &gate_V35_2016a_SIM_B.SFunctionBuilder_o3,
    &gate_V35_2016a_SIM_B.SFunctionBuilder_o4,
    &gate_V35_2016a_SIM_B.SFunctionBuilder_o5 );

  /* Update for UnitDelay: '<S15>/Unit Delay' */
  gate_V35_2016a_SIM_DW.UnitDelay_DSTATE_e = gate_V35_2016a_SIM_B.readReq;

  /* Update for UnitDelay: '<S15>/Unit Delay1' */
  gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE_l = gate_V35_2016a_SIM_B.clearReq;

  /* Update for UnitDelay: '<S15>/Unit Delay2' */
  gate_V35_2016a_SIM_DW.UnitDelay2_DSTATE_e = gate_V35_2016a_SIM_B.writeReq;

  /* End of Outputs for SubSystem: '<S11>/EEPROM_UPDATE' */

  /* Update for UnitDelay: '<S36>/Unit Delay' */
  gate_V35_2016a_SIM_DW.UnitDelay_DSTATE =
    gate_V35_2016a_SIM_B.rightSpeedRaw_UINT16;

  /* Update for UnitDelay: '<S36>/Unit Delay1' */
  gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE =
    gate_V35_2016a_SIM_B.leftSpeedRaw_UINT16;
}

/* Model initialize function */
void gate_V35_2016a_SIM_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(gate_V35_2016a_SIM_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &gate_V35_2016a_SIM_B), 0,
                sizeof(B_gate_V35_2016a_SIM_T));

  /* states (dwork) */
  (void) memset((void *)&gate_V35_2016a_SIM_DW, 0,
                sizeof(DW_gate_V35_2016a_SIM_T));

  {
    int16_T i;

    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S44>/Digital Output' */
    MW_pinModeOutput(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber);

    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S43>/Digital Output' */
    MW_pinModeOutput(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber_m);

    /* Start for S-Function (arduinodigitaloutput_sfcn): '<S45>/Digital Output' */
    MW_pinModeOutput(gate_V35_2016a_SIM_P.DigitalOutput_pinNumber_e);

    /* InitializeConditions for UnitDelay: '<S36>/Unit Delay' */
    gate_V35_2016a_SIM_DW.UnitDelay_DSTATE =
      gate_V35_2016a_SIM_P.UnitDelay_InitialCondition_a;

    /* InitializeConditions for UnitDelay: '<S36>/Unit Delay1' */
    gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE =
      gate_V35_2016a_SIM_P.UnitDelay1_InitialCondition_e;

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay3' */
    for (i = 0; i < 6; i++) {
      gate_V35_2016a_SIM_B.SFunctionBuilder_o1[i] =
        gate_V35_2016a_SIM_P.UnitDelay3_InitialCondition;
    }

    /* End of InitializeConditions for UnitDelay: '<S3>/Unit Delay3' */

    /* InitializeConditions for UnitDelay: '<S3>/Unit Delay2' */
    gate_V35_2016a_SIM_B.SFunctionBuilder_o5 =
      gate_V35_2016a_SIM_P.UnitDelay2_InitialCondition_d;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay' */
    gate_V35_2016a_SIM_B.SFunctionBuilder_o2 =
      gate_V35_2016a_SIM_P.UnitDelay_InitialCondition_e;

    /* InitializeConditions for UnitDelay: '<S11>/Unit Delay1' */
    gate_V35_2016a_SIM_B.SFunctionBuilder_o3 =
      gate_V35_2016a_SIM_P.UnitDelay1_InitialCondition_a;

    /* SystemInitialize for Chart: '<S36>/rightSquareWaveDetector' */
    ga_rightSquareWaveDetector_Init
      (&gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector,
       &gate_V35_2016a_SIM_DW.sf_rightSquareWaveDetector);

    /* SystemInitialize for Chart: '<S36>/rightSquareWaveDetector1' */
    ga_rightSquareWaveDetector_Init
      (&gate_V35_2016a_SIM_B.sf_rightSquareWaveDetector1,
       &gate_V35_2016a_SIM_DW.sf_rightSquareWaveDetector1);

    /* SystemInitialize for Chart: '<S23>/GateLogicStatemachine' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_closed =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_KpPassHandler =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_initTrailPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_closing =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_init = gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_AssignPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_open = gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_opening =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.temporalCounter_i2 = 0UL;
    gate_V35_2016a_SIM_DW.temporalCounter_i1 = 0U;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c20_gate_V35_2016a_SI = 0U;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c20_gate_V35_2016a_SIM =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.openingActive = 0U;
    for (i = 0; i < 6; i++) {
      gate_V35_2016a_SIM_DW.trialPass[i] = 0U;
    }

    gate_V35_2016a_SIM_DW.counter_e = 0U;
    gate_V35_2016a_SIM_DW.closing_active = 0U;
    gate_V35_2016a_SIM_DW.initCounter = 0U;
    gate_V35_2016a_SIM_DW.bitsForTID0.gotoReady = false;
    gate_V35_2016a_SIM_DW.passTimer = 0U;
    gate_V35_2016a_SIM_B.leftMotor = 0U;
    gate_V35_2016a_SIM_B.rightMotor = 0U;
    gate_V35_2016a_SIM_B.bulbPin_BOOL = false;
    gate_V35_2016a_SIM_B.passAssignedRAM_BOOL = false;
    gate_V35_2016a_SIM_B.passSuccess = 0U;
    for (i = 0; i < 6; i++) {
      gate_V35_2016a_SIM_B.passwordRAM_UINT8_6D[i] = 0U;
    }

    gate_V35_2016a_SIM_B.gateState = 0U;

    /* End of SystemInitialize for Chart: '<S23>/GateLogicStatemachine' */

    /* SystemInitialize for Chart: '<S26>/LedHandler' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_AssigningPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_EnteringPass =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c16_gate_V35_2016a_SI = 0U;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c16_gate_V35_2016a_SIM =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_DW.counter = 0U;
    gate_V35_2016a_SIM_B.greenLedPin_BOOL = false;
    gate_V35_2016a_SIM_B.redLedPin_BOOL = false;
    gate_V35_2016a_SIM_B.yellowLedPin_BOOL = false;

    /* SystemInitialize for Chart: '<S27>/MotorsHandler' */
    gate_V35_2016a_SIM_B.LeftMotorPin_BOOL = false;
    gate_V35_2016a_SIM_B.ComMotorPin_BOOL = true;
    gate_V35_2016a_SIM_B.RightMotorPin_BOOL = false;

    /* SystemInitialize for Chart: '<S11>/EEPROM_Control' */
    gate_V35_2016a_SIM_DW.bitsForTID0.is_active_c7_gate_V35_2016a_SIM = 0U;
    gate_V35_2016a_SIM_DW.bitsForTID0.is_c7_gate_V35_2016a_SIM =
      gate_V35_2_IN_NO_ACTIVE_CHILD_g;
    gate_V35_2016a_SIM_B.clearReq = false;
    gate_V35_2016a_SIM_B.readReq = false;
    gate_V35_2016a_SIM_B.writeReq = false;

    /* SystemInitialize for Atomic SubSystem: '<S11>/EEPROM_UPDATE' */
    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay' */
    gate_V35_2016a_SIM_DW.UnitDelay_DSTATE_e =
      gate_V35_2016a_SIM_P.UnitDelay_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay1' */
    gate_V35_2016a_SIM_DW.UnitDelay1_DSTATE_l =
      gate_V35_2016a_SIM_P.UnitDelay1_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S15>/Unit Delay2' */
    gate_V35_2016a_SIM_DW.UnitDelay2_DSTATE_e =
      gate_V35_2016a_SIM_P.UnitDelay2_InitialCondition;

    /* End of SystemInitialize for SubSystem: '<S11>/EEPROM_UPDATE' */
  }
}

/* Model terminate function */
void gate_V35_2016a_SIM_terminate(void)
{
  /* (no terminate code required) */
}
