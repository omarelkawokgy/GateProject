function CodeDefine() { 
this.def = new Array();
this.def["IsrOverrun"] = {file: "ert_main_c.html",line:4,type:"var"};
this.def["OverrunFlag"] = {file: "ert_main_c.html",line:5,type:"var"};
this.def["rt_OneStep"] = {file: "ert_main_c.html",line:6,type:"fcn"};
this.def["main"] = {file: "ert_main_c.html",line:33,type:"fcn"};
this.def["gate_V35_2016a_SIM_B"] = {file: "gate_V35_2016a_SIM_c.html",line:74,type:"var"};
this.def["gate_V35_2016a_SIM_DW"] = {file: "gate_V35_2016a_SIM_c.html",line:77,type:"var"};
this.def["gate_V35_2016a_SIM_M_"] = {file: "gate_V35_2016a_SIM_c.html",line:80,type:"var"};
this.def["gate_V35_2016a_SIM_M"] = {file: "gate_V35_2016a_SIM_c.html",line:81,type:"var"};
this.def["ga_rightSquareWaveDetector_Init"] = {file: "gate_V35_2016a_SIM_c.html",line:93,type:"fcn"};
this.def["gate_V3_rightSquareWaveDetector"] = {file: "gate_V35_2016a_SIM_c.html",line:110,type:"fcn"};
this.def["gate_V35_2016a_SIM_closed"] = {file: "gate_V35_2016a_SIM_c.html",line:208,type:"fcn"};
this.def["gate_V35_2016a_SIM_step"] = {file: "gate_V35_2016a_SIM_c.html",line:602,type:"fcn"};
this.def["gate_V35_2016a_SIM_initialize"] = {file: "gate_V35_2016a_SIM_c.html",line:1855,type:"fcn"};
this.def["gate_V35_2016a_SIM_terminate"] = {file: "gate_V35_2016a_SIM_c.html",line:2007,type:"fcn"};
this.def["B_rightSquareWaveDetector_gat_T"] = {file: "gate_V35_2016a_SIM_h.html",line:47,type:"type"};
this.def["DW_rightSquareWaveDetector_ga_T"] = {file: "gate_V35_2016a_SIM_h.html",line:58,type:"type"};
this.def["B_gate_V35_2016a_SIM_T"] = {file: "gate_V35_2016a_SIM_h.html",line:93,type:"type"};
this.def["DW_gate_V35_2016a_SIM_T"] = {file: "gate_V35_2016a_SIM_h.html",line:139,type:"type"};
this.def["P_gate_V35_2016a_SIM_T"] = {file: "gate_V35_2016a_SIM_types_h.html",line:21,type:"type"};
this.def["RT_MODEL_gate_V35_2016a_SIM_T"] = {file: "gate_V35_2016a_SIM_types_h.html",line:24,type:"type"};
this.def["gate_V35_2016a_SIM_P"] = {file: "gate_V35_2016a_SIM_data_c.html",line:20,type:"var"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:47,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:48,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:49,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:50,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:51,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:52,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:60,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:61,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:62,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:63,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:64,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:65,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:66,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["creal32_T"] = {file: "rtwtypes_h.html",line:78,type:"type"};
this.def["creal64_T"] = {file: "rtwtypes_h.html",line:83,type:"type"};
this.def["creal_T"] = {file: "rtwtypes_h.html",line:88,type:"type"};
this.def["cint8_T"] = {file: "rtwtypes_h.html",line:95,type:"type"};
this.def["cuint8_T"] = {file: "rtwtypes_h.html",line:102,type:"type"};
this.def["cint16_T"] = {file: "rtwtypes_h.html",line:109,type:"type"};
this.def["cuint16_T"] = {file: "rtwtypes_h.html",line:116,type:"type"};
this.def["cint32_T"] = {file: "rtwtypes_h.html",line:123,type:"type"};
this.def["cuint32_T"] = {file: "rtwtypes_h.html",line:130,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:148,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["ert_main_c.html"] = "../ert_main.c";
	this.html2Root["ert_main_c.html"] = "ert_main_c.html";
	this.html2SrcPath["gate_V35_2016a_SIM_c.html"] = "../gate_V35_2016a_SIM.c";
	this.html2Root["gate_V35_2016a_SIM_c.html"] = "gate_V35_2016a_SIM_c.html";
	this.html2SrcPath["gate_V35_2016a_SIM_h.html"] = "../gate_V35_2016a_SIM.h";
	this.html2Root["gate_V35_2016a_SIM_h.html"] = "gate_V35_2016a_SIM_h.html";
	this.html2SrcPath["gate_V35_2016a_SIM_private_h.html"] = "../gate_V35_2016a_SIM_private.h";
	this.html2Root["gate_V35_2016a_SIM_private_h.html"] = "gate_V35_2016a_SIM_private_h.html";
	this.html2SrcPath["gate_V35_2016a_SIM_types_h.html"] = "../gate_V35_2016a_SIM_types.h";
	this.html2Root["gate_V35_2016a_SIM_types_h.html"] = "gate_V35_2016a_SIM_types_h.html";
	this.html2SrcPath["gate_V35_2016a_SIM_data_c.html"] = "../gate_V35_2016a_SIM_data.c";
	this.html2Root["gate_V35_2016a_SIM_data_c.html"] = "gate_V35_2016a_SIM_data_c.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.html2SrcPath["rtmodel_h.html"] = "../rtmodel.h";
	this.html2Root["rtmodel_h.html"] = "rtmodel_h.html";
	this.html2SrcPath["MW_target_hardware_resources_h.html"] = "../MW_target_hardware_resources.h";
	this.html2Root["MW_target_hardware_resources_h.html"] = "MW_target_hardware_resources_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"ert_main_c.html","gate_V35_2016a_SIM_c.html","gate_V35_2016a_SIM_h.html","gate_V35_2016a_SIM_private_h.html","gate_V35_2016a_SIM_types_h.html","gate_V35_2016a_SIM_data_c.html","rtwtypes_h.html","rtmodel_h.html","MW_target_hardware_resources_h.html"];
