/*
 * gate_V35_2016a_SIM.h
 *
 * Code generation for model "gate_V35_2016a_SIM".
 *
 * Model version              : 1.340
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V35_2016a_SIM_h_
#define RTW_HEADER_gate_V35_2016a_SIM_h_
#include <stddef.h>
#include <string.h>
#ifndef gate_V35_2016a_SIM_COMMON_INCLUDES_
# define gate_V35_2016a_SIM_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "arduino_digitaloutput_lct.h"
#endif                                 /* gate_V35_2016a_SIM_COMMON_INCLUDES_ */

#include "gate_V35_2016a_SIM_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* user code (top of header file) */
//#include "C:\Users\omaro\Desktop\Gate_Model\Arduino\Arduino.h"
//#include "Keypad\Keypad.h"

/* Block signals for system '<S36>/rightSquareWaveDetector' */
typedef struct {
  uint8_T currentValue;                /* '<S36>/rightSquareWaveDetector' */
} B_rightSquareWaveDetector_gat_T;

/* Block states (auto storage) for system '<S36>/rightSquareWaveDetector' */
typedef struct {
  uint16_T counterHigh;                /* '<S36>/rightSquareWaveDetector' */
  uint16_T counterLow;                 /* '<S36>/rightSquareWaveDetector' */
  struct {
    uint_T is_c22_gate_V35_2016a_SIM:2;/* '<S36>/rightSquareWaveDetector' */
    uint_T is_Running:2;               /* '<S36>/rightSquareWaveDetector' */
    uint_T is_active_c22_gate_V35_2016a_SI:1;/* '<S36>/rightSquareWaveDetector' */
  } bitsForTID0;
} DW_rightSquareWaveDetector_ga_T;

/* Block signals (auto storage) */
typedef struct {
  uint8_T KeypadLib;                   /* '<S12>/KeypadLib' */
  uint8_T leftMotor;                   /* '<S23>/GateLogicStatemachine' */
  uint8_T rightMotor;                  /* '<S23>/GateLogicStatemachine' */
  uint8_T passSuccess;                 /* '<S23>/GateLogicStatemachine' */
  uint8_T passwordRAM_UINT8_6D[6];     /* '<S23>/GateLogicStatemachine' */
  uint8_T gateState;                   /* '<S23>/GateLogicStatemachine' */
  uint8_T SFunctionBuilder_o1[6];      /* '<S15>/S-Function Builder' */
  boolean_T SFunctionBuilder1_o1;      /* '<S10>/S-Function Builder1' */
  boolean_T SFunctionBuilder1_o2;      /* '<S10>/S-Function Builder1' */
  boolean_T rightSpeedRaw_UINT16;      /* '<S5>/S-Function Builder4' */
  boolean_T leftSpeedRaw_UINT16;       /* '<S5>/S-Function Builder3' */
  boolean_T bulbPin_BOOL;              /* '<S23>/GateLogicStatemachine' */
  boolean_T passAssignedRAM_BOOL;      /* '<S23>/GateLogicStatemachine' */
  boolean_T LeftMotorPin_BOOL;         /* '<S27>/MotorsHandler' */
  boolean_T ComMotorPin_BOOL;          /* '<S27>/MotorsHandler' */
  boolean_T RightMotorPin_BOOL;        /* '<S27>/MotorsHandler' */
  boolean_T greenLedPin_BOOL;          /* '<S26>/LedHandler' */
  boolean_T redLedPin_BOOL;            /* '<S26>/LedHandler' */
  boolean_T yellowLedPin_BOOL;         /* '<S26>/LedHandler' */
  boolean_T UnitDelay;                 /* '<S15>/Unit Delay' */
  boolean_T UnitDelay1;                /* '<S15>/Unit Delay1' */
  boolean_T UnitDelay2_a;              /* '<S15>/Unit Delay2' */
  boolean_T SFunctionBuilder_o2;       /* '<S15>/S-Function Builder' */
  boolean_T SFunctionBuilder_o3;       /* '<S15>/S-Function Builder' */
  boolean_T SFunctionBuilder_o4;       /* '<S15>/S-Function Builder' */
  boolean_T SFunctionBuilder_o5;       /* '<S15>/S-Function Builder' */
  boolean_T clearReq;                  /* '<S11>/EEPROM_Control' */
  boolean_T readReq;                   /* '<S11>/EEPROM_Control' */
  boolean_T writeReq;                  /* '<S11>/EEPROM_Control' */
  B_rightSquareWaveDetector_gat_T sf_rightSquareWaveDetector1;/* '<S36>/rightSquareWaveDetector1' */
  B_rightSquareWaveDetector_gat_T sf_rightSquareWaveDetector;/* '<S36>/rightSquareWaveDetector' */
} B_gate_V35_2016a_SIM_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  uint8_T trialPass[6];                /* '<S23>/GateLogicStatemachine' */
  uint32_T temporalCounter_i2;         /* '<S23>/GateLogicStatemachine' */
  uint16_T passTimer;                  /* '<S23>/GateLogicStatemachine' */
  uint16_T temporalCounter_i1;         /* '<S23>/GateLogicStatemachine' */
  uint16_T counter;                    /* '<S26>/LedHandler' */
  struct {
    uint_T is_c20_gate_V35_2016a_SIM:3;/* '<S23>/GateLogicStatemachine' */
    uint_T is_KpPassHandler:3;         /* '<S23>/GateLogicStatemachine' */
    uint_T is_c16_gate_V35_2016a_SIM:3;/* '<S26>/LedHandler' */
    uint_T is_c7_gate_V35_2016a_SIM:3; /* '<S11>/EEPROM_Control' */
    uint_T is_init:2;                  /* '<S23>/GateLogicStatemachine' */
    uint_T is_AssignPass:2;            /* '<S23>/GateLogicStatemachine' */
    uint_T is_closed:2;                /* '<S23>/GateLogicStatemachine' */
    uint_T is_opening:2;               /* '<S23>/GateLogicStatemachine' */
    uint_T is_closing:2;               /* '<S23>/GateLogicStatemachine' */
    uint_T is_open:2;                  /* '<S23>/GateLogicStatemachine' */
    uint_T is_AssigningPass:2;         /* '<S26>/LedHandler' */
    uint_T is_EnteringPass:2;          /* '<S26>/LedHandler' */
    uint_T is_active_c20_gate_V35_2016a_SI:1;/* '<S23>/GateLogicStatemachine' */
    uint_T is_initTrailPass:1;         /* '<S23>/GateLogicStatemachine' */
    uint_T is_active_c16_gate_V35_2016a_SI:1;/* '<S26>/LedHandler' */
    uint_T is_active_c7_gate_V35_2016a_SIM:1;/* '<S11>/EEPROM_Control' */
    uint_T gotoReady:1;                /* '<S23>/GateLogicStatemachine' */
  } bitsForTID0;

  boolean_T UnitDelay_DSTATE;          /* '<S36>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE;         /* '<S36>/Unit Delay1' */
  boolean_T UnitDelay_DSTATE_e;        /* '<S15>/Unit Delay' */
  boolean_T UnitDelay1_DSTATE_l;       /* '<S15>/Unit Delay1' */
  boolean_T UnitDelay2_DSTATE_e;       /* '<S15>/Unit Delay2' */
  uint8_T openingActive;               /* '<S23>/GateLogicStatemachine' */
  uint8_T counter_e;                   /* '<S23>/GateLogicStatemachine' */
  uint8_T closing_active;              /* '<S23>/GateLogicStatemachine' */
  uint8_T initCounter;                 /* '<S23>/GateLogicStatemachine' */
  uint8_T KpCharPressed_start;         /* '<S23>/GateLogicStatemachine' */
  uint8_T KpCharPressed_start_g;       /* '<S26>/LedHandler' */
  boolean_T RFPressedOut_UINT8_start;  /* '<S23>/GateLogicStatemachine' */
  boolean_T passSwitch_start;          /* '<S23>/GateLogicStatemachine' */
  boolean_T PassSw_start;              /* '<S26>/LedHandler' */
  boolean_T passSw_start;              /* '<S11>/EEPROM_Control' */
  DW_rightSquareWaveDetector_ga_T sf_rightSquareWaveDetector1;/* '<S36>/rightSquareWaveDetector1' */
  DW_rightSquareWaveDetector_ga_T sf_rightSquareWaveDetector;/* '<S36>/rightSquareWaveDetector' */
} DW_gate_V35_2016a_SIM_T;

/* Parameters (auto storage) */
struct P_gate_V35_2016a_SIM_T_ {
  real32_T CLOSE_SIDE_VALUE;           /* Variable: CLOSE_SIDE_VALUE
                                        * Referenced by: '<S23>/CLOSE_SIDE_VALUE'
                                        */
  uint32_T MOVING_TIMER;               /* Variable: MOVING_TIMER
                                        * Referenced by: '<S23>/MOVING_TIMER'
                                        */
  uint16_T CURRENT_THRESH;             /* Variable: CURRENT_THRESH
                                        * Referenced by:
                                        *   '<S36>/WRONG_PASSWORD2'
                                        *   '<S36>/WRONG_PASSWORD3'
                                        */
  uint16_T OPEN_SIDE_VALUE;            /* Variable: OPEN_SIDE_VALUE
                                        * Referenced by: '<S23>/OPEN_SIDE_VALUE'
                                        */
  uint16_T PASS_TIMEOUT;               /* Variable: PASS_TIMEOUT
                                        * Referenced by: '<S23>/PASS_TIMEOUT'
                                        */
  uint8_T CLOSED;                      /* Variable: CLOSED
                                        * Referenced by:
                                        *   '<S23>/CLOSED'
                                        *   '<S26>/CLOSED'
                                        *   '<S27>/CLOSED'
                                        */
  uint8_T CLOSE_CHAR;                  /* Variable: CLOSE_CHAR
                                        * Referenced by:
                                        *   '<S23>/CLOSE_CHAR'
                                        *   '<S26>/CLOSE_CHAR'
                                        */
  uint8_T CLOSING;                     /* Variable: CLOSING
                                        * Referenced by:
                                        *   '<S23>/CLOSING'
                                        *   '<S26>/CLOSING'
                                        *   '<S27>/CLOSING'
                                        */
  uint8_T CURRENT_STABLE_TIMER;        /* Variable: CURRENT_STABLE_TIMER
                                        * Referenced by:
                                        *   '<S36>/WRONG_PASSWORD'
                                        *   '<S36>/WRONG_PASSWORD1'
                                        */
  uint8_T INIT;                        /* Variable: INIT
                                        * Referenced by:
                                        *   '<S23>/INIT'
                                        *   '<S26>/INIT'
                                        *   '<S27>/OPENING1'
                                        */
  uint8_T NO_PASS_ASSIG;               /* Variable: NO_PASS_ASSIG
                                        * Referenced by:
                                        *   '<S23>/NO_PASS_ASSIG'
                                        *   '<S26>/NO_PASS_ASSIG'
                                        */
  uint8_T OPEN;                        /* Variable: OPEN
                                        * Referenced by:
                                        *   '<S23>/OPEN'
                                        *   '<S26>/OPEN'
                                        *   '<S27>/OPEN'
                                        */
  uint8_T OPENING;                     /* Variable: OPENING
                                        * Referenced by:
                                        *   '<S23>/OPENING'
                                        *   '<S26>/OPENING'
                                        *   '<S27>/OPENING'
                                        */
  uint8_T OPENING_ACTIVE;              /* Variable: OPENING_ACTIVE
                                        * Referenced by: '<S23>/OPENING_ACTIVE'
                                        */
  uint8_T OPEN_CHAR;                   /* Variable: OPEN_CHAR
                                        * Referenced by:
                                        *   '<S23>/OPEN_CHAR'
                                        *   '<S26>/OPEN_CHAR'
                                        */
  uint8_T PASSWORD_VERIFIED;           /* Variable: PASSWORD_VERIFIED
                                        * Referenced by:
                                        *   '<S23>/PASSWORD_VERIFIED'
                                        *   '<S26>/PASSWORD_VERIFIED'
                                        */
  uint8_T PASS_ASSIGNED;               /* Variable: PASS_ASSIGNED
                                        * Referenced by: '<S23>/PASS_ASSIGNED'
                                        */
  uint8_T PASS_INCOMPLETE;             /* Variable: PASS_INCOMPLETE
                                        * Referenced by: '<S23>/PASS_INCOMPLETE'
                                        */
  uint8_T STABLE_TIMER_VALUE;          /* Variable: STABLE_TIMER_VALUE
                                        * Referenced by: '<S23>/STABLE_TIMER_VALUE'
                                        */
  uint8_T TIMEOUT;                     /* Variable: TIMEOUT
                                        * Referenced by:
                                        *   '<S23>/TIMEOUT'
                                        *   '<S26>/TIMEOUT'
                                        */
  uint8_T WRONG_PASSWORD;              /* Variable: WRONG_PASSWORD
                                        * Referenced by:
                                        *   '<S23>/WRONG_PASSWORD'
                                        *   '<S26>/WRONG_PASSWORD'
                                        */
  uint32_T DigitalOutput_pinNumber;    /* Mask Parameter: DigitalOutput_pinNumber
                                        * Referenced by: '<S44>/Digital Output'
                                        */
  uint32_T DigitalOutput_pinNumber_m;  /* Mask Parameter: DigitalOutput_pinNumber_m
                                        * Referenced by: '<S43>/Digital Output'
                                        */
  uint32_T DigitalOutput_pinNumber_e;  /* Mask Parameter: DigitalOutput_pinNumber_e
                                        * Referenced by: '<S45>/Digital Output'
                                        */
  uint8_T UnitDelay3_InitialCondition; /* Computed Parameter: UnitDelay3_InitialCondition
                                        * Referenced by: '<S3>/Unit Delay3'
                                        */
  boolean_T UnitDelay_InitialCondition;/* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S15>/Unit Delay'
                                        */
  boolean_T UnitDelay1_InitialCondition;/* Computed Parameter: UnitDelay1_InitialCondition
                                         * Referenced by: '<S15>/Unit Delay1'
                                         */
  boolean_T UnitDelay2_InitialCondition;/* Computed Parameter: UnitDelay2_InitialCondition
                                         * Referenced by: '<S15>/Unit Delay2'
                                         */
  boolean_T UnitDelay_InitialCondition_a;/* Computed Parameter: UnitDelay_InitialCondition_a
                                          * Referenced by: '<S36>/Unit Delay'
                                          */
  boolean_T UnitDelay1_InitialCondition_e;/* Computed Parameter: UnitDelay1_InitialCondition_e
                                           * Referenced by: '<S36>/Unit Delay1'
                                           */
  boolean_T UnitDelay2_InitialCondition_d;/* Computed Parameter: UnitDelay2_InitialCondition_d
                                           * Referenced by: '<S3>/Unit Delay2'
                                           */
  boolean_T UnitDelay_InitialCondition_e;/* Computed Parameter: UnitDelay_InitialCondition_e
                                          * Referenced by: '<S11>/Unit Delay'
                                          */
  boolean_T UnitDelay1_InitialCondition_a;/* Computed Parameter: UnitDelay1_InitialCondition_a
                                           * Referenced by: '<S11>/Unit Delay1'
                                           */
};

/* Real-time Model Data Structure */
struct tag_RTM_gate_V35_2016a_SIM_T {
  const char_T *errorStatus;
};

/* Block parameters (auto storage) */
extern P_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_P;

/* Block signals (auto storage) */
extern B_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_B;

/* Block states (auto storage) */
extern DW_gate_V35_2016a_SIM_T gate_V35_2016a_SIM_DW;

/* Model entry point functions */
extern void gate_V35_2016a_SIM_initialize(void);
extern void gate_V35_2016a_SIM_step(void);
extern void gate_V35_2016a_SIM_terminate(void);

/* Real-time Model object */
extern RT_MODEL_gate_V35_2016a_SIM_T *const gate_V35_2016a_SIM_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Data Type Conversion2' : Unused code path elimination
 * Block '<S22>/Constant' : Unused code path elimination
 * Block '<S36>/Data Type Conversion' : Unused code path elimination
 * Block '<S36>/Data Type Conversion1' : Unused code path elimination
 * Block '<S1>/Data Type Conversion' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion1' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion11' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion3' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion4' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion5' : Eliminate redundant data type conversion
 * Block '<S1>/Data Type Conversion6' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'gate_V35_2016a_SIM'
 * '<S1>'   : 'gate_V35_2016a_SIM/Gate'
 * '<S2>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper'
 * '<S3>'   : 'gate_V35_2016a_SIM/Gate/Subsystem'
 * '<S4>'   : 'gate_V35_2016a_SIM/Gate/outputPinsBlock'
 * '<S5>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL'
 * '<S6>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_A'
 * '<S7>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_B'
 * '<S8>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_C'
 * '<S9>'   : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/BluetoothWrapper'
 * '<S10>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/ButtonsPressed'
 * '<S11>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/EEPROM'
 * '<S12>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/KeypadWrapper'
 * '<S13>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/currentSensorWrapperOld'
 * '<S14>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_Control'
 * '<S15>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/EEPROM/EEPROM_UPDATE'
 * '<S16>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/currentSensorWrapperOld/Slider Gain'
 * '<S17>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/HIL/currentSensorWrapperOld/SquareWaveDetector'
 * '<S18>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_A/Signal Builder'
 * '<S19>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_B/Signal Builder'
 * '<S20>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_B/Signal Builder1'
 * '<S21>'  : 'gate_V35_2016a_SIM/Gate/HardwareInputWrapper/MIL_Gate_C/Signal Builder'
 * '<S22>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF'
 * '<S23>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_Variant_KP_RF'
 * '<S24>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/CurrentFilterSubsystem'
 * '<S25>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/Subsystem1'
 * '<S26>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler'
 * '<S27>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler'
 * '<S28>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/SquareWaveCreator'
 * '<S29>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler'
 * '<S30>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/LedHandler/LedHandler_old1'
 * '<S31>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler'
 * '<S32>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/MotorHandler/MotorsHandler1'
 * '<S33>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_HardwareOutputWrapper_KP_RF/SquareWaveCreator/SquareWaveCreator'
 * '<S34>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/B_Variant_KP_RF/GateLogicStatemachine'
 * '<S35>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/CurrentFilterSubsystem/10msSmapler'
 * '<S36>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/CurrentFilterSubsystem/Subsystem'
 * '<S37>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector'
 * '<S38>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/CurrentFilterSubsystem/Subsystem/rightSquareWaveDetector1'
 * '<S39>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/Subsystem1/10msSmapler'
 * '<S40>'  : 'gate_V35_2016a_SIM/Gate/Subsystem/Subsystem1/Subsystem'
 * '<S41>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/HIL'
 * '<S42>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL'
 * '<S43>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/HIL/Digital Output'
 * '<S44>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/HIL/Digital Output1'
 * '<S45>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/HIL/Digital Output2'
 * '<S46>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/ScopeBlocks'
 * '<S47>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks '
 * '<S48>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /BTCheck'
 * '<S49>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /BulbCheck'
 * '<S50>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /GreenLedCheck'
 * '<S51>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /MCCheck'
 * '<S52>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /MLCheck'
 * '<S53>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /MRCheck'
 * '<S54>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /RedLedCheck'
 * '<S55>'  : 'gate_V35_2016a_SIM/Gate/outputPinsBlock/MIL/VerificationBlocks /YellowLedCheck'
 */
#endif                                 /* RTW_HEADER_gate_V35_2016a_SIM_h_ */
