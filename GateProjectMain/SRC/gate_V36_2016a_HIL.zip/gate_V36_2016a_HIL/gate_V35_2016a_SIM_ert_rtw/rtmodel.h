/*
 * rtmodel.h
 *
 * Code generation for Simulink model "gate_V35_2016a_SIM".
 *
 * Simulink Coder version                : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Note that the generated code is not dependent on this header file.
 * The file is used in cojuction with the automatic build procedure.
 * It is included by the sample main executable harness
 * MATLAB/rtw/c/src/common/rt_main.c.
 *
 */

#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "gate_V35_2016a_SIM.h"

/* Macros generated for backwards compatibility  */
#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((void*) 0)
#endif
#endif                                 /* RTW_HEADER_rtmodel_h_ */
