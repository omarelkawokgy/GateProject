/*
 * gate_V35_2016a_SIM_private.h
 *
 * Code generation for model "gate_V35_2016a_SIM".
 *
 * Model version              : 1.340
 * Simulink Coder version : 8.10 (R2016a) 10-Feb-2016
 * C source code generated on : Wed Mar 07 03:03:45 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V35_2016a_SIM_private_h_
#define RTW_HEADER_gate_V35_2016a_SIM_private_h_
#include "rtwtypes.h"
#include "gate_V35_2016a_SIM.h"

extern void myEEPROM_Handler_Outputs_wrapper(const uint8_T *passwordIn,
  const boolean_T *readReq,
  const boolean_T *oldReadReq,
  const boolean_T *clearReq,
  const boolean_T *oldClearReq,
  const boolean_T *writeReq,
  const boolean_T *oldWriteReq,
  const boolean_T *passAssignedIn,
  uint8_T *passwordOut,
  boolean_T *readComplete,
  boolean_T *writeComplete,
  boolean_T *clearComplete,
  boolean_T *passAssignedOut);
extern void Button_Lib_Outputs_wrapper(boolean_T *RFInput,
  boolean_T *passSw);
extern void keypadLib_Outputs_wrapper(uint8_T *charPressed);
extern void A0PIN_Lib_Outputs_wrapper(boolean_T *output);
extern void A1PIN_Lib_Outputs_wrapper(boolean_T *output);
extern void A3PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A4PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A5PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A2PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void ga_rightSquareWaveDetector_Init(B_rightSquareWaveDetector_gat_T
  *localB, DW_rightSquareWaveDetector_ga_T *localDW);
extern void gate_V3_rightSquareWaveDetector(boolean_T rtu_CurrentAnalogIn,
  boolean_T rtu_CurrentAnalogInOld, uint8_T rtu_CURRENT_STABLE_TIMER,
  B_rightSquareWaveDetector_gat_T *localB, DW_rightSquareWaveDetector_ga_T
  *localDW);

#endif                                 /* RTW_HEADER_gate_V35_2016a_SIM_private_h_ */
