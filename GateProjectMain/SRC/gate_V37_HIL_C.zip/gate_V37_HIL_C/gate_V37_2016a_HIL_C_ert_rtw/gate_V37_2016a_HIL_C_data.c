/*
 * File: gate_V37_2016a_HIL_C_data.c
 *
 * Code generated for Simulink model 'gate_V37_2016a_HIL_C'.
 *
 * Model version                  : 1.352
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Mon May 28 00:43:12 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "gate_V37_2016a_HIL_C.h"
#include "gate_V37_2016a_HIL_C_private.h"

/* Block parameters (auto storage) */
P_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_P = {
  4000.0F,                             /* Variable: CLOSE_SIDE_VALUE
                                        * Referenced by: '<S24>/CLOSE_SIDE_VALUE'
                                        */
  60000U,                              /* Variable: MOVING_TIMER
                                        * Referenced by: '<S24>/MOVING_TIMER'
                                        */
  1000U,                               /* Variable: CURRENT_THRESH
                                        * Referenced by:
                                        *   '<S30>/WRONG_PASSWORD2'
                                        *   '<S30>/WRONG_PASSWORD3'
                                        */
  4000U,                               /* Variable: OPEN_SIDE_VALUE
                                        * Referenced by: '<S24>/OPEN_SIDE_VALUE'
                                        */
  1000U,                               /* Variable: STABLE_TIMER_VALUE
                                        * Referenced by: '<S24>/STABLE_TIMER_VALUE'
                                        */
  12U,                                 /* Variable: CLOSED
                                        * Referenced by:
                                        *   '<S24>/CLOSED'
                                        *   '<S26>/CLOSED'
                                        */
  13U,                                 /* Variable: CLOSING
                                        * Referenced by:
                                        *   '<S24>/CLOSING'
                                        *   '<S26>/CLOSING'
                                        */
  200U,                                /* Variable: CURRENT_STABLE_TIMER
                                        * Referenced by:
                                        *   '<S30>/WRONG_PASSWORD'
                                        *   '<S30>/WRONG_PASSWORD1'
                                        */
  15U,                                 /* Variable: INIT
                                        * Referenced by:
                                        *   '<S24>/INIT'
                                        *   '<S26>/OPENING1'
                                        */
  14U,                                 /* Variable: OPEN
                                        * Referenced by:
                                        *   '<S24>/OPEN'
                                        *   '<S26>/OPEN'
                                        */
  11U,                                 /* Variable: OPENING
                                        * Referenced by:
                                        *   '<S24>/OPENING'
                                        *   '<S26>/OPENING'
                                        */
  1U,                                  /* Variable: OPENING_ACTIVE
                                        * Referenced by: '<S24>/OPENING_ACTIVE'
                                        */
  0U,                                  /* Computed Parameter: UnitDelay1_InitialCondition
                                        * Referenced by: '<S30>/Unit Delay1'
                                        */
  0                                    /* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S30>/Unit Delay'
                                        */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
