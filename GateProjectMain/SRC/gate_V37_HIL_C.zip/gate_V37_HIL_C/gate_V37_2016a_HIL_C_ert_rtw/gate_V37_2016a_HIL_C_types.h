/*
 * gate_V37_2016a_HIL_C_types.h
 *
 * Code generation for model "gate_V37_2016a_HIL_C".
 *
 * Model version              : 1.352
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon May 28 00:43:12 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V37_2016a_HIL_C_types_h_
#define RTW_HEADER_gate_V37_2016a_HIL_C_types_h_
#include "rtwtypes.h"

/* Parameters (auto storage) */
typedef struct P_gate_V37_2016a_HIL_C_T_ P_gate_V37_2016a_HIL_C_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_gate_V37_2016a_HIL_C_T RT_MODEL_gate_V37_2016a_HIL_C_T;

#endif                                 /* RTW_HEADER_gate_V37_2016a_HIL_C_types_h_ */
