/*
 * gate_V37_2016a_HIL_C.h
 *
 * Code generation for model "gate_V37_2016a_HIL_C".
 *
 * Model version              : 1.352
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon May 28 00:43:12 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V37_2016a_HIL_C_h_
#define RTW_HEADER_gate_V37_2016a_HIL_C_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef gate_V37_2016a_HIL_C_COMMON_INCLUDES_
# define gate_V37_2016a_HIL_C_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* gate_V37_2016a_HIL_C_COMMON_INCLUDES_ */

#include "gate_V37_2016a_HIL_C_types.h"
#include "MW_target_hardware_resources.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

/* user code (top of header file) */
//#include "C:\Users\omaro\Desktop\Gate_Model\Arduino\Arduino.h"
//#include "Keypad\Keypad.h"

/* Block signals (auto storage) */
typedef struct {
  real_T leftSpeedRaw_UINT16;          /* '<S6>/S-Function Builder3' */
  uint16_T DataTypeConversion3;        /* '<S1>/Data Type Conversion3' */
  uint8_T currentValue;                /* '<S30>/rightSquareWaveDetector' */
  uint8_T currentValue_p;              /* '<S30>/leftSquareWaveDetector' */
  uint8_T leftMotor;                   /* '<S24>/GateLogicStatemachine' */
  uint8_T rightMotor;                  /* '<S24>/GateLogicStatemachine' */
  uint8_T gateState;                   /* '<S24>/GateLogicStatemachine' */
  boolean_T SFunctionBuilder1_o1;      /* '<S18>/S-Function Builder1' */
  boolean_T SFunctionBuilder1_o2;      /* '<S18>/S-Function Builder1' */
  boolean_T rightSpeedRaw_UINT16;      /* '<S6>/S-Function Builder4' */
  boolean_T bulbPin_BOOL;              /* '<S24>/GateLogicStatemachine' */
  boolean_T LeftMotorPin_BOOL;         /* '<S26>/MotorsHandler' */
  boolean_T ComMotorPin_BOOL;          /* '<S26>/MotorsHandler' */
  boolean_T RightMotorPin_BOOL;        /* '<S26>/MotorsHandler' */
} B_gate_V37_2016a_HIL_C_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  uint32_T temporalCounter_i2;         /* '<S24>/GateLogicStatemachine' */
  uint16_T UnitDelay1_DSTATE;          /* '<S30>/Unit Delay1' */
  uint16_T counterHigh;                /* '<S30>/rightSquareWaveDetector' */
  uint16_T counterLow;                 /* '<S30>/rightSquareWaveDetector' */
  uint16_T counterHigh_i;              /* '<S30>/leftSquareWaveDetector' */
  uint16_T counterLow_l;               /* '<S30>/leftSquareWaveDetector' */
  uint16_T temporalCounter_i1;         /* '<S24>/GateLogicStatemachine' */
  struct {
    uint_T is_c24_gate_V37_2016a_HIL_C:3;/* '<S24>/GateLogicStatemachine' */
    uint_T is_c22_gate_V37_2016a_HIL_C:2;/* '<S30>/rightSquareWaveDetector' */
    uint_T is_Running:2;               /* '<S30>/rightSquareWaveDetector' */
    uint_T is_c1_gate_V37_2016a_HIL_C:2;/* '<S30>/leftSquareWaveDetector' */
    uint_T is_Running_p:2;             /* '<S30>/leftSquareWaveDetector' */
    uint_T is_opening:2;               /* '<S24>/GateLogicStatemachine' */
    uint_T is_closed:2;                /* '<S24>/GateLogicStatemachine' */
    uint_T is_closing:2;               /* '<S24>/GateLogicStatemachine' */
    uint_T is_open:2;                  /* '<S24>/GateLogicStatemachine' */
    uint_T is_active_c22_gate_V37_2016a_HI:1;/* '<S30>/rightSquareWaveDetector' */
    uint_T is_active_c1_gate_V37_2016a_HIL:1;/* '<S30>/leftSquareWaveDetector' */
    uint_T is_active_c24_gate_V37_2016a_HI:1;/* '<S24>/GateLogicStatemachine' */
  } bitsForTID1;

  boolean_T UnitDelay_DSTATE;          /* '<S30>/Unit Delay' */
  uint8_T openingActive;               /* '<S24>/GateLogicStatemachine' */
  uint8_T closing_active;              /* '<S24>/GateLogicStatemachine' */
  boolean_T RFPressedOut_UINT8_start;  /* '<S24>/GateLogicStatemachine' */
  boolean_T passSwitch_start;          /* '<S24>/GateLogicStatemachine' */
} DW_gate_V37_2016a_HIL_C_T;

/* Parameters (auto storage) */
struct P_gate_V37_2016a_HIL_C_T_ {
  real32_T CLOSE_SIDE_VALUE;           /* Variable: CLOSE_SIDE_VALUE
                                        * Referenced by: '<S24>/CLOSE_SIDE_VALUE'
                                        */
  uint32_T MOVING_TIMER;               /* Variable: MOVING_TIMER
                                        * Referenced by: '<S24>/MOVING_TIMER'
                                        */
  uint16_T CURRENT_THRESH;             /* Variable: CURRENT_THRESH
                                        * Referenced by:
                                        *   '<S30>/WRONG_PASSWORD2'
                                        *   '<S30>/WRONG_PASSWORD3'
                                        */
  uint16_T OPEN_SIDE_VALUE;            /* Variable: OPEN_SIDE_VALUE
                                        * Referenced by: '<S24>/OPEN_SIDE_VALUE'
                                        */
  uint16_T STABLE_TIMER_VALUE;         /* Variable: STABLE_TIMER_VALUE
                                        * Referenced by: '<S24>/STABLE_TIMER_VALUE'
                                        */
  uint8_T CLOSED;                      /* Variable: CLOSED
                                        * Referenced by:
                                        *   '<S24>/CLOSED'
                                        *   '<S26>/CLOSED'
                                        */
  uint8_T CLOSING;                     /* Variable: CLOSING
                                        * Referenced by:
                                        *   '<S24>/CLOSING'
                                        *   '<S26>/CLOSING'
                                        */
  uint8_T CURRENT_STABLE_TIMER;        /* Variable: CURRENT_STABLE_TIMER
                                        * Referenced by:
                                        *   '<S30>/WRONG_PASSWORD'
                                        *   '<S30>/WRONG_PASSWORD1'
                                        */
  uint8_T INIT;                        /* Variable: INIT
                                        * Referenced by:
                                        *   '<S24>/INIT'
                                        *   '<S26>/OPENING1'
                                        */
  uint8_T OPEN;                        /* Variable: OPEN
                                        * Referenced by:
                                        *   '<S24>/OPEN'
                                        *   '<S26>/OPEN'
                                        */
  uint8_T OPENING;                     /* Variable: OPENING
                                        * Referenced by:
                                        *   '<S24>/OPENING'
                                        *   '<S26>/OPENING'
                                        */
  uint8_T OPENING_ACTIVE;              /* Variable: OPENING_ACTIVE
                                        * Referenced by: '<S24>/OPENING_ACTIVE'
                                        */
  uint16_T UnitDelay1_InitialCondition;/* Computed Parameter: UnitDelay1_InitialCondition
                                        * Referenced by: '<S30>/Unit Delay1'
                                        */
  boolean_T UnitDelay_InitialCondition;/* Computed Parameter: UnitDelay_InitialCondition
                                        * Referenced by: '<S30>/Unit Delay'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_gate_V37_2016a_HIL_C_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern P_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_P;

/* Block signals (auto storage) */
extern B_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_B;

/* Block states (auto storage) */
extern DW_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_DW;

/* Model entry point functions */
extern void gate_V37_2016a_HIL_C_initialize(void);
extern void gate_V37_2016a_HIL_C_step(void);
extern void gate_V37_2016a_HIL_C_terminate(void);

/* Real-time Model object */
extern RT_MODEL_gate_V37_2016a_HIL_C_T *const gate_V37_2016a_HIL_C_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S23>/Constant' : Unused code path elimination
 * Block '<S23>/Constant1' : Unused code path elimination
 * Block '<S23>/Constant2' : Unused code path elimination
 * Block '<S23>/Constant3' : Unused code path elimination
 * Block '<S30>/Data Type Conversion' : Unused code path elimination
 * Block '<S30>/Data Type Conversion1' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'gate_V37_2016a_HIL_C'
 * '<S1>'   : 'gate_V37_2016a_HIL_C/Gate'
 * '<S2>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper'
 * '<S3>'   : 'gate_V37_2016a_HIL_C/Gate/Subsystem'
 * '<S4>'   : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock'
 * '<S5>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B'
 * '<S6>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_C'
 * '<S7>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_A'
 * '<S8>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_B'
 * '<S9>'   : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_C'
 * '<S10>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/BluetoothWrapper'
 * '<S11>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/ButtonsPressed'
 * '<S12>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/EEPROM'
 * '<S13>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/KeypadWrapper'
 * '<S14>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/currentSensorWrapperOld'
 * '<S15>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/EEPROM/EEPROM_Control'
 * '<S16>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/EEPROM/EEPROM_UPDATE'
 * '<S17>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_B/currentSensorWrapperOld/SquareWaveDetector'
 * '<S18>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/HIL_C/ButtonsPressed'
 * '<S19>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_A/Signal Builder'
 * '<S20>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_B/Signal Builder'
 * '<S21>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_B/Signal Builder1'
 * '<S22>'  : 'gate_V37_2016a_HIL_C/Gate/HardwareInputWrapper/MIL_Gate_C/Signal Builder'
 * '<S23>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/C_HardwareOutputWrapper_RF'
 * '<S24>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/C_Variant_RF'
 * '<S25>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/CurrentFilter'
 * '<S26>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/C_HardwareOutputWrapper_RF/MotorHandler'
 * '<S27>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/C_HardwareOutputWrapper_RF/MotorHandler/MotorsHandler'
 * '<S28>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/C_Variant_RF/GateLogicStatemachine'
 * '<S29>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/CurrentFilter/10msSmapler'
 * '<S30>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/CurrentFilter/Subsystem'
 * '<S31>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/CurrentFilter/Subsystem/leftSquareWaveDetector'
 * '<S32>'  : 'gate_V37_2016a_HIL_C/Gate/Subsystem/CurrentFilter/Subsystem/rightSquareWaveDetector'
 * '<S33>'  : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock/HIL_B'
 * '<S34>'  : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock/HIL_C'
 * '<S35>'  : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock/MIL'
 * '<S36>'  : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock/MIL/ScopeBlocks'
 * '<S37>'  : 'gate_V37_2016a_HIL_C/Gate/outputPinsBlock/MIL/VerificationBlocks '
 */
#endif                                 /* RTW_HEADER_gate_V37_2016a_HIL_C_h_ */
