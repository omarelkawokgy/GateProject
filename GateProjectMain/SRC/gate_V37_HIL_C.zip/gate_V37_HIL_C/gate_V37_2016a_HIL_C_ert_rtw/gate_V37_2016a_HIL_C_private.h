/*
 * gate_V37_2016a_HIL_C_private.h
 *
 * Code generation for model "gate_V37_2016a_HIL_C".
 *
 * Model version              : 1.352
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon May 28 00:43:12 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_gate_V37_2016a_HIL_C_private_h_
#define RTW_HEADER_gate_V37_2016a_HIL_C_private_h_
#include "rtwtypes.h"

/* Private macros used by the generated code to access rtModel */
#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

extern void Button_Lib_Outputs_wrapper(boolean_T *RFInput,
  boolean_T *passSw);
extern void A0PIN_Lib_Outputs_wrapper(boolean_T *output);
extern void A1PIN_Lib_Outputs_wrapper(real_T *output);
extern void A3PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A4PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A5PIN_Lib_Outputs_wrapper(const boolean_T *input);
extern void A2PIN_Lib_Outputs_wrapper(const boolean_T *input);

#endif                                 /* RTW_HEADER_gate_V37_2016a_HIL_C_private_h_ */
