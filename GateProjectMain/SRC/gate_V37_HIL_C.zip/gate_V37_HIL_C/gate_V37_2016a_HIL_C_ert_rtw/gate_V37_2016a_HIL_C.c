/*
 * gate_V37_2016a_HIL_C.c
 *
 * Code generation for model "gate_V37_2016a_HIL_C".
 *
 * Model version              : 1.352
 * Simulink Coder version : 8.11 (R2016b) 25-Aug-2016
 * C source code generated on : Mon May 28 00:43:12 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "gate_V37_2016a_HIL_C.h"
#include "gate_V37_2016a_HIL_C_private.h"

/* Named constants for Chart: '<S24>/GateLogicStatemachine' */
#define gate_V37_2016a_HIL_C_IN_closed ((uint8_T)1U)
#define gate_V37_2016a_HIL_C_IN_closing ((uint8_T)2U)
#define gate_V37_2016a_HIL_C_IN_init   ((uint8_T)3U)
#define gate_V37_2016a_HIL_C_IN_open   ((uint8_T)4U)
#define gate_V37_2016a_HIL_C_IN_opening ((uint8_T)5U)
#define gate_V37_2016a_HIL_IN_closing_c ((uint8_T)1U)
#define gate_V37_2016a_HIL__IN_gateOpen ((uint8_T)2U)
#define gate_V37_2016a_H_IN_openingGate ((uint8_T)2U)
#define gate_V37_2016a_IN_openRightSide ((uint8_T)2U)
#define gate_V37_2016a__IN_MonitorInput ((uint8_T)1U)
#define gate_V37_2016a__IN_openLeftSide ((uint8_T)1U)
#define gate_V37_201_IN_closingLeftSide ((uint8_T)1U)
#define gate_V37_20_IN_closingRightSide ((uint8_T)2U)

/* Named constants for Chart: '<S30>/leftSquareWaveDetector' */
#define gate_V37_2016a_HIL_C_IN_High   ((uint8_T)1U)
#define gate_V37_2016a_HIL_C_IN_Low    ((uint8_T)2U)
#define gate_V37_2016a_HIL_C_IN_Running ((uint8_T)1U)
#define gate_V37_2016a_HIL_C_IN_Stop   ((uint8_T)2U)

/* Block signals (auto storage) */
B_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_B;

/* Block states (auto storage) */
DW_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_DW;

/* Real-time model */
RT_MODEL_gate_V37_2016a_HIL_C_T gate_V37_2016a_HIL_C_M_;
RT_MODEL_gate_V37_2016a_HIL_C_T *const gate_V37_2016a_HIL_C_M =
  &gate_V37_2016a_HIL_C_M_;

/* Model step function */
void gate_V37_2016a_HIL_C_step(void)
{
  boolean_T rtb_LogicalOperator;
  uint16_T rtb_UnitDelay1;
  boolean_T RFPressedOut_UINT8_prev;
  boolean_T passSwitch_prev;
  real_T tmp;

  /* S-Function (Button_Lib): '<S18>/S-Function Builder1' */
  Button_Lib_Outputs_wrapper( &gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1,
    &gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2 );

  /* S-Function (A0PIN_Lib): '<S6>/S-Function Builder4' */
  A0PIN_Lib_Outputs_wrapper( &gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 );

  /* Chart: '<S30>/rightSquareWaveDetector' incorporates:
   *  Constant: '<S30>/WRONG_PASSWORD'
   *  Constant: '<S30>/WRONG_PASSWORD2'
   *  UnitDelay: '<S30>/Unit Delay'
   */
  /* Gateway: Gate/Subsystem/CurrentFilter/Subsystem/rightSquareWaveDetector */
  /* During: Gate/Subsystem/CurrentFilter/Subsystem/rightSquareWaveDetector */
  if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c22_gate_V37_2016a_HI == 0U)
  {
    /* Entry: Gate/Subsystem/CurrentFilter/Subsystem/rightSquareWaveDetector */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c22_gate_V37_2016a_HI = 1U;

    /* Entry Internal: Gate/Subsystem/CurrentFilter/Subsystem/rightSquareWaveDetector */
    /* Transition: '<S32>:6' */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c22_gate_V37_2016a_HIL_C =
      gate_V37_2016a_HIL_C_IN_Stop;

    /* Entry 'Stop': '<S32>:5' */
    gate_V37_2016a_HIL_C_B.currentValue = 0U;
  } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c22_gate_V37_2016a_HIL_C ==
             gate_V37_2016a_HIL_C_IN_Running) {
    /* During 'Running': '<S32>:13' */
    if ((gate_V37_2016a_HIL_C_DW.counterHigh >=
         gate_V37_2016a_HIL_C_P.CURRENT_STABLE_TIMER) ||
        (gate_V37_2016a_HIL_C_DW.counterLow >=
         gate_V37_2016a_HIL_C_P.CURRENT_STABLE_TIMER)) {
      /* Transition: '<S32>:16' */
      /* Exit Internal 'Running': '<S32>:13' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running = 0U;
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c22_gate_V37_2016a_HIL_C =
        gate_V37_2016a_HIL_C_IN_Stop;

      /* Entry 'Stop': '<S32>:5' */
      gate_V37_2016a_HIL_C_B.currentValue = 0U;
    } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running ==
               gate_V37_2016a_HIL_C_IN_High) {
      /* During 'High': '<S32>:7' */
      if ((uint16_T)gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
        /* Transition: '<S32>:10' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running =
          gate_V37_2016a_HIL_C_IN_Low;

        /* Entry 'Low': '<S32>:8' */
        gate_V37_2016a_HIL_C_DW.counterHigh = 0U;
      } else {
        if ((uint16_T)gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 >
            gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
          /* Transition: '<S32>:12' */
          rtb_UnitDelay1 = gate_V37_2016a_HIL_C_DW.counterHigh + /*MW:OvSatOk*/
            1U;
          if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_DW.counterHigh) {
            rtb_UnitDelay1 = MAX_uint16_T;
          }

          gate_V37_2016a_HIL_C_DW.counterHigh = rtb_UnitDelay1;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running =
            gate_V37_2016a_HIL_C_IN_High;

          /* Entry 'High': '<S32>:7' */
          gate_V37_2016a_HIL_C_DW.counterLow = 0U;
        }
      }
    } else {
      /* During 'Low': '<S32>:8' */
      if ((uint16_T)gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 >
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
        /* Transition: '<S32>:11' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running =
          gate_V37_2016a_HIL_C_IN_High;

        /* Entry 'High': '<S32>:7' */
        gate_V37_2016a_HIL_C_DW.counterLow = 0U;
      } else {
        if ((uint16_T)gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 <
            gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
          /* Transition: '<S32>:14' */
          rtb_UnitDelay1 = gate_V37_2016a_HIL_C_DW.counterLow + /*MW:OvSatOk*/
            1U;
          if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_DW.counterLow) {
            rtb_UnitDelay1 = MAX_uint16_T;
          }

          gate_V37_2016a_HIL_C_DW.counterLow = rtb_UnitDelay1;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running =
            gate_V37_2016a_HIL_C_IN_Low;

          /* Entry 'Low': '<S32>:8' */
          gate_V37_2016a_HIL_C_DW.counterHigh = 0U;
        }
      }
    }
  } else {
    /* During 'Stop': '<S32>:5' */
    if ((((uint16_T)gate_V37_2016a_HIL_C_DW.UnitDelay_DSTATE >
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) && ((uint16_T)
          gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH)) || (((uint16_T)
          gate_V37_2016a_HIL_C_DW.UnitDelay_DSTATE <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) && ((uint16_T)
          gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16 >
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH))) {
      /* Transition: '<S32>:9' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c22_gate_V37_2016a_HIL_C =
        gate_V37_2016a_HIL_C_IN_Running;

      /* Entry 'Running': '<S32>:13' */
      gate_V37_2016a_HIL_C_DW.counterHigh = 0U;
      gate_V37_2016a_HIL_C_B.currentValue = 1U;

      /* Entry Internal 'Running': '<S32>:13' */
      /* Transition: '<S32>:17' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running =
        gate_V37_2016a_HIL_C_IN_High;

      /* Entry 'High': '<S32>:7' */
      gate_V37_2016a_HIL_C_DW.counterLow = 0U;
    }
  }

  /* End of Chart: '<S30>/rightSquareWaveDetector' */

  /* S-Function (A1PIN_Lib): '<S6>/S-Function Builder3' */
  A1PIN_Lib_Outputs_wrapper( &gate_V37_2016a_HIL_C_B.leftSpeedRaw_UINT16 );

  /* DataTypeConversion: '<S1>/Data Type Conversion3' */
  tmp = floor(gate_V37_2016a_HIL_C_B.leftSpeedRaw_UINT16);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 65536.0);
  }

  gate_V37_2016a_HIL_C_B.DataTypeConversion3 = tmp < 0.0 ? (uint16_T)-(int16_T)
    (uint16_T)-tmp : (uint16_T)tmp;

  /* End of DataTypeConversion: '<S1>/Data Type Conversion3' */

  /* UnitDelay: '<S30>/Unit Delay1' */
  rtb_UnitDelay1 = gate_V37_2016a_HIL_C_DW.UnitDelay1_DSTATE;

  /* Chart: '<S30>/leftSquareWaveDetector' incorporates:
   *  Constant: '<S30>/WRONG_PASSWORD1'
   *  Constant: '<S30>/WRONG_PASSWORD3'
   */
  /* Gateway: Gate/Subsystem/CurrentFilter/Subsystem/leftSquareWaveDetector */
  /* During: Gate/Subsystem/CurrentFilter/Subsystem/leftSquareWaveDetector */
  if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c1_gate_V37_2016a_HIL == 0U)
  {
    /* Entry: Gate/Subsystem/CurrentFilter/Subsystem/leftSquareWaveDetector */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c1_gate_V37_2016a_HIL = 1U;

    /* Entry Internal: Gate/Subsystem/CurrentFilter/Subsystem/leftSquareWaveDetector */
    /* Transition: '<S31>:6' */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c1_gate_V37_2016a_HIL_C =
      gate_V37_2016a_HIL_C_IN_Stop;

    /* Entry 'Stop': '<S31>:5' */
    gate_V37_2016a_HIL_C_B.currentValue_p = 0U;
  } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c1_gate_V37_2016a_HIL_C ==
             gate_V37_2016a_HIL_C_IN_Running) {
    /* During 'Running': '<S31>:13' */
    if ((gate_V37_2016a_HIL_C_DW.counterHigh_i >=
         gate_V37_2016a_HIL_C_P.CURRENT_STABLE_TIMER) ||
        (gate_V37_2016a_HIL_C_DW.counterLow_l >=
         gate_V37_2016a_HIL_C_P.CURRENT_STABLE_TIMER)) {
      /* Transition: '<S31>:16' */
      /* Exit Internal 'Running': '<S31>:13' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p = 0U;
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c1_gate_V37_2016a_HIL_C =
        gate_V37_2016a_HIL_C_IN_Stop;

      /* Entry 'Stop': '<S31>:5' */
      gate_V37_2016a_HIL_C_B.currentValue_p = 0U;
    } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p ==
               gate_V37_2016a_HIL_C_IN_High) {
      /* During 'High': '<S31>:7' */
      if (gate_V37_2016a_HIL_C_B.DataTypeConversion3 <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
        /* Transition: '<S31>:10' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p =
          gate_V37_2016a_HIL_C_IN_Low;

        /* Entry 'Low': '<S31>:8' */
        gate_V37_2016a_HIL_C_DW.counterHigh_i = 0U;
      } else {
        if (gate_V37_2016a_HIL_C_B.DataTypeConversion3 >
            gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
          /* Transition: '<S31>:12' */
          rtb_UnitDelay1 = gate_V37_2016a_HIL_C_DW.counterHigh_i +
            /*MW:OvSatOk*/ 1U;
          if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_DW.counterHigh_i) {
            rtb_UnitDelay1 = MAX_uint16_T;
          }

          gate_V37_2016a_HIL_C_DW.counterHigh_i = rtb_UnitDelay1;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p =
            gate_V37_2016a_HIL_C_IN_High;

          /* Entry 'High': '<S31>:7' */
          gate_V37_2016a_HIL_C_DW.counterLow_l = 0U;
        }
      }
    } else {
      /* During 'Low': '<S31>:8' */
      if (gate_V37_2016a_HIL_C_B.DataTypeConversion3 >
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
        /* Transition: '<S31>:11' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p =
          gate_V37_2016a_HIL_C_IN_High;

        /* Entry 'High': '<S31>:7' */
        gate_V37_2016a_HIL_C_DW.counterLow_l = 0U;
      } else {
        if (gate_V37_2016a_HIL_C_B.DataTypeConversion3 <
            gate_V37_2016a_HIL_C_P.CURRENT_THRESH) {
          /* Transition: '<S31>:14' */
          rtb_UnitDelay1 = gate_V37_2016a_HIL_C_DW.counterLow_l + /*MW:OvSatOk*/
            1U;
          if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_DW.counterLow_l) {
            rtb_UnitDelay1 = MAX_uint16_T;
          }

          gate_V37_2016a_HIL_C_DW.counterLow_l = rtb_UnitDelay1;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p =
            gate_V37_2016a_HIL_C_IN_Low;

          /* Entry 'Low': '<S31>:8' */
          gate_V37_2016a_HIL_C_DW.counterHigh_i = 0U;
        }
      }
    }
  } else {
    /* During 'Stop': '<S31>:5' */
    if (((rtb_UnitDelay1 > gate_V37_2016a_HIL_C_P.CURRENT_THRESH) &&
         (gate_V37_2016a_HIL_C_B.DataTypeConversion3 <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH)) || ((rtb_UnitDelay1 <
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH) &&
         (gate_V37_2016a_HIL_C_B.DataTypeConversion3 >
          gate_V37_2016a_HIL_C_P.CURRENT_THRESH))) {
      /* Transition: '<S31>:9' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c1_gate_V37_2016a_HIL_C =
        gate_V37_2016a_HIL_C_IN_Running;

      /* Entry 'Running': '<S31>:13' */
      gate_V37_2016a_HIL_C_DW.counterHigh_i = 0U;
      gate_V37_2016a_HIL_C_B.currentValue_p = 1U;

      /* Entry Internal 'Running': '<S31>:13' */
      /* Transition: '<S31>:17' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p =
        gate_V37_2016a_HIL_C_IN_High;

      /* Entry 'High': '<S31>:7' */
      gate_V37_2016a_HIL_C_DW.counterLow_l = 0U;
    }
  }

  /* End of Chart: '<S30>/leftSquareWaveDetector' */

  /* Logic: '<S30>/Logical Operator' */
  rtb_LogicalOperator = ((gate_V37_2016a_HIL_C_B.currentValue != 0) ||
    (gate_V37_2016a_HIL_C_B.currentValue_p != 0));

  /* Chart: '<S24>/GateLogicStatemachine' incorporates:
   *  Constant: '<S24>/CLOSED'
   *  Constant: '<S24>/CLOSE_SIDE_VALUE'
   *  Constant: '<S24>/CLOSING'
   *  Constant: '<S24>/INIT'
   *  Constant: '<S24>/MOVING_TIMER'
   *  Constant: '<S24>/OPEN'
   *  Constant: '<S24>/OPENING'
   *  Constant: '<S24>/OPENING_ACTIVE'
   *  Constant: '<S24>/OPEN_SIDE_VALUE'
   *  Constant: '<S24>/STABLE_TIMER_VALUE'
   */
  /* Gateway: Gate/Subsystem/C_Variant_RF/GateLogicStatemachine */
  if (gate_V37_2016a_HIL_C_DW.temporalCounter_i1 < MAX_uint16_T) {
    gate_V37_2016a_HIL_C_DW.temporalCounter_i1++;
  }

  if (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 < MAX_uint32_T) {
    gate_V37_2016a_HIL_C_DW.temporalCounter_i2++;
  }

  RFPressedOut_UINT8_prev = gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start;
  gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start =
    gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1;
  passSwitch_prev = gate_V37_2016a_HIL_C_DW.passSwitch_start;
  gate_V37_2016a_HIL_C_DW.passSwitch_start =
    gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2;

  /* During: Gate/Subsystem/C_Variant_RF/GateLogicStatemachine */
  if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c24_gate_V37_2016a_HI == 0U)
  {
    /* Entry: Gate/Subsystem/C_Variant_RF/GateLogicStatemachine */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c24_gate_V37_2016a_HI = 1U;

    /* Entry Internal: Gate/Subsystem/C_Variant_RF/GateLogicStatemachine */
    /* Transition: '<S28>:34' */
    gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
      gate_V37_2016a_HIL_C_IN_init;

    /* Entry 'init': '<S28>:365' */
    gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
    gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
    gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
    gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.INIT;
  } else {
    switch (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C) {
     case gate_V37_2016a_HIL_C_IN_closed:
      /* During 'closed': '<S28>:32' */
      if (gate_V37_2016a_HIL_C_DW.openingActive ==
          gate_V37_2016a_HIL_C_P.OPENING_ACTIVE) {
        /* Transition: '<S28>:86' */
        /* Exit Internal 'closed': '<S28>:32' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_opening;
        gate_V37_2016a_HIL_C_DW.temporalCounter_i2 = 0UL;

        /* Entry 'opening': '<S28>:183' */
        gate_V37_2016a_HIL_C_B.bulbPin_BOOL = true;
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.OPENING;

        /* Entry Internal 'opening': '<S28>:183' */
        /* Transition: '<S28>:189' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening =
          gate_V37_2016a__IN_openLeftSide;
        gate_V37_2016a_HIL_C_DW.temporalCounter_i1 = 0U;

        /* Entry 'openLeftSide': '<S28>:83' */
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.OPENING;
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSED;
      } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed ==
                 gate_V37_2016a__IN_MonitorInput) {
        /* During 'MonitorInput': '<S28>:29' */
        if (gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1 &&
            (RFPressedOut_UINT8_prev !=
             gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start)) {
          /* Transition: '<S28>:245' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
            gate_V37_2016a_H_IN_openingGate;

          /* Entry 'openingGate': '<S28>:23' */
          gate_V37_2016a_HIL_C_DW.openingActive =
            gate_V37_2016a_HIL_C_P.OPENING_ACTIVE;
        } else {
          if (gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2 && (passSwitch_prev !=
               gate_V37_2016a_HIL_C_DW.passSwitch_start)) {
            /* Transition: '<S28>:368' */
            gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
              gate_V37_2016a_H_IN_openingGate;

            /* Entry 'openingGate': '<S28>:23' */
            gate_V37_2016a_HIL_C_DW.openingActive =
              gate_V37_2016a_HIL_C_P.OPENING_ACTIVE;
          }
        }
      } else {
        /* During 'openingGate': '<S28>:23' */
      }
      break;

     case gate_V37_2016a_HIL_C_IN_closing:
      /* During 'closing': '<S28>:206' */
      if (((gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1 &&
            (RFPressedOut_UINT8_prev !=
             gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start)) ||
           (gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2 && (passSwitch_prev !=
             gate_V37_2016a_HIL_C_DW.passSwitch_start))) &&
          (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >= (uint32_T)
           (gate_V37_2016a_HIL_C_P.CLOSE_SIDE_VALUE + (real32_T)
            gate_V37_2016a_HIL_C_P.STABLE_TIMER_VALUE))) {
        /* Transition: '<S28>:371' */
        /* Transition: '<S28>:384' */
        /* Exit Internal 'closing': '<S28>:206' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_closed;

        /* Entry 'closed': '<S28>:32' */
        gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_DW.openingActive = 0U;
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.CLOSED;

        /* Entry Internal 'closed': '<S28>:32' */
        /* Transition: '<S28>:30' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
          gate_V37_2016a__IN_MonitorInput;
      } else if ((!rtb_LogicalOperator) &&
                 (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >= (uint32_T)
                  (gate_V37_2016a_HIL_C_P.CLOSE_SIDE_VALUE + (real32_T)
                   gate_V37_2016a_HIL_C_P.STABLE_TIMER_VALUE))) {
        /* Transition: '<S28>:207' */
        /* Exit Internal 'closing': '<S28>:206' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_closed;

        /* Entry 'closed': '<S28>:32' */
        gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_DW.openingActive = 0U;
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.CLOSED;

        /* Entry Internal 'closed': '<S28>:32' */
        /* Transition: '<S28>:30' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
          gate_V37_2016a__IN_MonitorInput;
      } else if (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >=
                 gate_V37_2016a_HIL_C_P.MOVING_TIMER) {
        /* Transition: '<S28>:373' */
        /* Exit Internal 'closing': '<S28>:206' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_closed;

        /* Entry 'closed': '<S28>:32' */
        gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
        gate_V37_2016a_HIL_C_DW.openingActive = 0U;
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.CLOSED;

        /* Entry Internal 'closed': '<S28>:32' */
        /* Transition: '<S28>:30' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
          gate_V37_2016a__IN_MonitorInput;
      } else if ((gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing !=
                  gate_V37_201_IN_closingLeftSide) &&
                 (gate_V37_2016a_HIL_C_DW.temporalCounter_i1 >= (uint16_T)
                  gate_V37_2016a_HIL_C_P.CLOSE_SIDE_VALUE)) {
        /* During 'closingRightSide': '<S28>:211' */
        /* Transition: '<S28>:213' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing =
          gate_V37_201_IN_closingLeftSide;

        /* Entry 'closingLeftSide': '<S28>:212' */
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
      } else {
        /* During 'closingLeftSide': '<S28>:212' */
      }
      break;

     case gate_V37_2016a_HIL_C_IN_init:
      /* During 'init': '<S28>:365' */
      /* Transition: '<S28>:367' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
        gate_V37_2016a_HIL_C_IN_closed;

      /* Entry 'closed': '<S28>:32' */
      gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
      gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.CLOSING;
      gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
      gate_V37_2016a_HIL_C_DW.openingActive = 0U;
      gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.CLOSED;

      /* Entry Internal 'closed': '<S28>:32' */
      /* Transition: '<S28>:30' */
      gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed =
        gate_V37_2016a__IN_MonitorInput;
      break;

     case gate_V37_2016a_HIL_C_IN_open:
      /* During 'open': '<S28>:197' */
      if (gate_V37_2016a_HIL_C_DW.closing_active == 1) {
        /* Transition: '<S28>:198' */
        /* Exit Internal 'open': '<S28>:197' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_closing;
        gate_V37_2016a_HIL_C_DW.temporalCounter_i2 = 0UL;

        /* Entry 'closing': '<S28>:206' */
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.CLOSING;

        /* Entry Internal 'closing': '<S28>:206' */
        /* Transition: '<S28>:223' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing =
          gate_V37_20_IN_closingRightSide;
        gate_V37_2016a_HIL_C_DW.temporalCounter_i1 = 0U;

        /* Entry 'closingRightSide': '<S28>:211' */
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.CLOSING;
      } else if (gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open !=
                 gate_V37_2016a_HIL_IN_closing_c) {
        /* During 'gateOpen': '<S28>:84' */
        if ((RFPressedOut_UINT8_prev !=
             gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start) &&
            gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1) {
          /* Transition: '<S28>:203' */
          /* Transition: '<S28>:386' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open =
            gate_V37_2016a_HIL_IN_closing_c;

          /* Entry 'closing': '<S28>:196' */
          gate_V37_2016a_HIL_C_DW.closing_active = 1U;
        } else {
          if (gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2 && (passSwitch_prev !=
               gate_V37_2016a_HIL_C_DW.passSwitch_start)) {
            /* Transition: '<S28>:369' */
            gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open =
              gate_V37_2016a_HIL_IN_closing_c;

            /* Entry 'closing': '<S28>:196' */
            gate_V37_2016a_HIL_C_DW.closing_active = 1U;
          }
        }
      } else {
        /* During 'closing': '<S28>:196' */
      }
      break;

     default:
      /* During 'opening': '<S28>:183' */
      rtb_UnitDelay1 = gate_V37_2016a_HIL_C_P.OPEN_SIDE_VALUE + /*MW:OvSatOk*/
        gate_V37_2016a_HIL_C_P.STABLE_TIMER_VALUE;
      if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_P.OPEN_SIDE_VALUE) {
        rtb_UnitDelay1 = MAX_uint16_T;
      }

      if (((gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o1 &&
            (RFPressedOut_UINT8_prev !=
             gate_V37_2016a_HIL_C_DW.RFPressedOut_UINT8_start)) ||
           (gate_V37_2016a_HIL_C_B.SFunctionBuilder1_o2 && (passSwitch_prev !=
             gate_V37_2016a_HIL_C_DW.passSwitch_start))) &&
          (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >= rtb_UnitDelay1)) {
        /* Transition: '<S28>:370' */
        /* Transition: '<S28>:382' */
        /* Exit Internal 'opening': '<S28>:183' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening = 0U;
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
          gate_V37_2016a_HIL_C_IN_open;

        /* Entry 'open': '<S28>:197' */
        gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.OPEN;

        /* Entry Internal 'open': '<S28>:197' */
        /* Transition: '<S28>:224' */
        gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open =
          gate_V37_2016a_HIL__IN_gateOpen;

        /* Entry 'gateOpen': '<S28>:84' */
        gate_V37_2016a_HIL_C_DW.closing_active = 0U;
        gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.OPEN;
        gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.OPEN;
      } else {
        rtb_UnitDelay1 = gate_V37_2016a_HIL_C_P.OPEN_SIDE_VALUE + /*MW:OvSatOk*/
          gate_V37_2016a_HIL_C_P.STABLE_TIMER_VALUE;
        if (rtb_UnitDelay1 < gate_V37_2016a_HIL_C_P.OPEN_SIDE_VALUE) {
          rtb_UnitDelay1 = MAX_uint16_T;
        }

        if ((!rtb_LogicalOperator) &&
            (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >= rtb_UnitDelay1)) {
          /* Transition: '<S28>:184' */
          /* Exit Internal 'opening': '<S28>:183' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening = 0U;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
            gate_V37_2016a_HIL_C_IN_open;

          /* Entry 'open': '<S28>:197' */
          gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.OPEN;

          /* Entry Internal 'open': '<S28>:197' */
          /* Transition: '<S28>:224' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open =
            gate_V37_2016a_HIL__IN_gateOpen;

          /* Entry 'gateOpen': '<S28>:84' */
          gate_V37_2016a_HIL_C_DW.closing_active = 0U;
          gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.OPEN;
          gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.OPEN;
        } else if (gate_V37_2016a_HIL_C_DW.temporalCounter_i2 >=
                   gate_V37_2016a_HIL_C_P.MOVING_TIMER) {
          /* Transition: '<S28>:372' */
          /* Exit Internal 'opening': '<S28>:183' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening = 0U;
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C =
            gate_V37_2016a_HIL_C_IN_open;

          /* Entry 'open': '<S28>:197' */
          gate_V37_2016a_HIL_C_B.gateState = gate_V37_2016a_HIL_C_P.OPEN;

          /* Entry Internal 'open': '<S28>:197' */
          /* Transition: '<S28>:224' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open =
            gate_V37_2016a_HIL__IN_gateOpen;

          /* Entry 'gateOpen': '<S28>:84' */
          gate_V37_2016a_HIL_C_DW.closing_active = 0U;
          gate_V37_2016a_HIL_C_B.leftMotor = gate_V37_2016a_HIL_C_P.OPEN;
          gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.OPEN;
        } else if ((gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening ==
                    gate_V37_2016a__IN_openLeftSide) &&
                   (gate_V37_2016a_HIL_C_DW.temporalCounter_i1 >=
                    gate_V37_2016a_HIL_C_P.OPEN_SIDE_VALUE)) {
          /* During 'openLeftSide': '<S28>:83' */
          /* Transition: '<S28>:188' */
          gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening =
            gate_V37_2016a_IN_openRightSide;

          /* Entry 'openRightSide': '<S28>:182' */
          gate_V37_2016a_HIL_C_B.rightMotor = gate_V37_2016a_HIL_C_P.OPENING;
        } else {
          /* During 'openRightSide': '<S28>:182' */
        }
      }
      break;
    }
  }

  /* End of Chart: '<S24>/GateLogicStatemachine' */

  /* Chart: '<S26>/MotorsHandler' incorporates:
   *  Constant: '<S26>/CLOSED'
   *  Constant: '<S26>/CLOSING'
   *  Constant: '<S26>/OPEN'
   *  Constant: '<S26>/OPENING'
   *  Constant: '<S26>/OPENING1'
   */
  /* Gateway: Gate/Subsystem/C_HardwareOutputWrapper_RF/MotorHandler/MotorsHandler */
  /* During: Gate/Subsystem/C_HardwareOutputWrapper_RF/MotorHandler/MotorsHandler */
  /* Entry Internal: Gate/Subsystem/C_HardwareOutputWrapper_RF/MotorHandler/MotorsHandler */
  /* Transition: '<S27>:171' */
  /*  updating motor Pins Switch case  */
  if ((gate_V37_2016a_HIL_C_B.leftMotor == gate_V37_2016a_HIL_C_P.OPENING) &&
      ((gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.CLOSED) ||
       (gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.OPEN))) {
    /* Transition: '<S27>:172' */
    /* Transition: '<S27>:173' */
    gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = true;
    gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
    gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;

    /* Transition: '<S27>:196' */
    /* Transition: '<S27>:197' */
    /* Transition: '<S27>:198' */
    /* Transition: '<S27>:203' */
    /* Transition: '<S27>:202' */
    /* Transition: '<S27>:201' */
    /* Transition: '<S27>:200' */
    /* Transition: '<S27>:199' */
  } else {
    /* Transition: '<S27>:174' */
    if ((gate_V37_2016a_HIL_C_B.leftMotor == gate_V37_2016a_HIL_C_P.CLOSING) &&
        ((gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.CLOSED) ||
         (gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.OPEN))) {
      /* Transition: '<S27>:175' */
      /* Transition: '<S27>:176' */
      gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
      gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = false;
      gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = true;

      /* Transition: '<S27>:197' */
      /* Transition: '<S27>:198' */
      /* Transition: '<S27>:203' */
      /* Transition: '<S27>:202' */
      /* Transition: '<S27>:201' */
      /* Transition: '<S27>:200' */
      /* Transition: '<S27>:199' */
    } else {
      /* Transition: '<S27>:177' */
      if ((gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.CLOSING) &&
          ((gate_V37_2016a_HIL_C_B.leftMotor == gate_V37_2016a_HIL_C_P.CLOSED) ||
           (gate_V37_2016a_HIL_C_B.leftMotor == gate_V37_2016a_HIL_C_P.OPEN))) {
        /* Transition: '<S27>:178' */
        /* Transition: '<S27>:179' */
        gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = true;
        gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = false;
        gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;

        /* Transition: '<S27>:198' */
        /* Transition: '<S27>:203' */
        /* Transition: '<S27>:202' */
        /* Transition: '<S27>:201' */
        /* Transition: '<S27>:200' */
        /* Transition: '<S27>:199' */
      } else {
        /* Transition: '<S27>:180' */
        if ((gate_V37_2016a_HIL_C_B.rightMotor == gate_V37_2016a_HIL_C_P.OPENING)
            && ((gate_V37_2016a_HIL_C_B.leftMotor ==
                 gate_V37_2016a_HIL_C_P.CLOSED) ||
                (gate_V37_2016a_HIL_C_B.leftMotor == gate_V37_2016a_HIL_C_P.OPEN)))
        {
          /* Transition: '<S27>:181' */
          /* Transition: '<S27>:182' */
          gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
          gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
          gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = true;

          /* Transition: '<S27>:203' */
          /* Transition: '<S27>:202' */
          /* Transition: '<S27>:201' */
          /* Transition: '<S27>:200' */
          /* Transition: '<S27>:199' */
        } else {
          /* Transition: '<S27>:183' */
          if ((gate_V37_2016a_HIL_C_B.rightMotor ==
               gate_V37_2016a_HIL_C_P.OPENING) &&
              (gate_V37_2016a_HIL_C_B.leftMotor ==
               gate_V37_2016a_HIL_C_P.OPENING)) {
            /* Transition: '<S27>:184' */
            /* Transition: '<S27>:185' */
            gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = true;
            gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
            gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = true;

            /* Transition: '<S27>:202' */
            /* Transition: '<S27>:201' */
            /* Transition: '<S27>:200' */
            /* Transition: '<S27>:199' */
          } else {
            /* Transition: '<S27>:186' */
            if ((gate_V37_2016a_HIL_C_B.rightMotor ==
                 gate_V37_2016a_HIL_C_P.CLOSING) &&
                (gate_V37_2016a_HIL_C_B.leftMotor ==
                 gate_V37_2016a_HIL_C_P.CLOSING)) {
              /* Transition: '<S27>:187' */
              /* Transition: '<S27>:189' */
              gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
              gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = false;
              gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;

              /* Transition: '<S27>:201' */
              /* Transition: '<S27>:200' */
              /* Transition: '<S27>:199' */
            } else {
              /* Transition: '<S27>:188' */
              if (((gate_V37_2016a_HIL_C_B.rightMotor ==
                    gate_V37_2016a_HIL_C_P.CLOSED) ||
                   (gate_V37_2016a_HIL_C_B.rightMotor ==
                    gate_V37_2016a_HIL_C_P.OPEN)) &&
                  ((gate_V37_2016a_HIL_C_B.leftMotor ==
                    gate_V37_2016a_HIL_C_P.CLOSED) ||
                   (gate_V37_2016a_HIL_C_B.leftMotor ==
                    gate_V37_2016a_HIL_C_P.OPEN))) {
                /* Transition: '<S27>:190' */
                /* Transition: '<S27>:192' */
                gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
                gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
                gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;

                /* Transition: '<S27>:200' */
                /* Transition: '<S27>:199' */
              } else {
                /* Transition: '<S27>:191' */
                if ((gate_V37_2016a_HIL_C_B.gateState ==
                     gate_V37_2016a_HIL_C_P.CLOSED) ||
                    (gate_V37_2016a_HIL_C_B.gateState ==
                     gate_V37_2016a_HIL_C_P.OPEN) ||
                    (gate_V37_2016a_HIL_C_B.gateState ==
                     gate_V37_2016a_HIL_C_P.INIT)) {
                  /* Transition: '<S27>:193' */
                  /* Transition: '<S27>:195' */
                  gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
                  gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
                  gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;

                  /* Transition: '<S27>:199' */
                } else {
                  /* Transition: '<S27>:194' */
                }
              }
            }
          }
        }
      }
    }
  }

  /* End of Chart: '<S26>/MotorsHandler' */
  /* Transition: '<S27>:204' */

  /* S-Function (A3PIN_Lib): '<S34>/S-Function Builder2' */
  A3PIN_Lib_Outputs_wrapper(&gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL );

  /* S-Function (A4PIN_Lib): '<S34>/S-Function Builder3' */
  A4PIN_Lib_Outputs_wrapper(&gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL );

  /* S-Function (A5PIN_Lib): '<S34>/S-Function Builder4' */
  A5PIN_Lib_Outputs_wrapper(&gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL );

  /* S-Function (A2PIN_Lib): '<S34>/S-Function Builder1' */
  A2PIN_Lib_Outputs_wrapper(&gate_V37_2016a_HIL_C_B.bulbPin_BOOL );

  /* Update for UnitDelay: '<S30>/Unit Delay' */
  gate_V37_2016a_HIL_C_DW.UnitDelay_DSTATE =
    gate_V37_2016a_HIL_C_B.rightSpeedRaw_UINT16;

  /* Update for UnitDelay: '<S30>/Unit Delay1' */
  gate_V37_2016a_HIL_C_DW.UnitDelay1_DSTATE =
    gate_V37_2016a_HIL_C_B.DataTypeConversion3;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  gate_V37_2016a_HIL_C_M->Timing.t[0] =
    (++gate_V37_2016a_HIL_C_M->Timing.clockTick0) *
    gate_V37_2016a_HIL_C_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    gate_V37_2016a_HIL_C_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void gate_V37_2016a_HIL_C_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)gate_V37_2016a_HIL_C_M, 0,
                sizeof(RT_MODEL_gate_V37_2016a_HIL_C_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&gate_V37_2016a_HIL_C_M->solverInfo,
                          &gate_V37_2016a_HIL_C_M->Timing.simTimeStep);
    rtsiSetTPtr(&gate_V37_2016a_HIL_C_M->solverInfo, &rtmGetTPtr
                (gate_V37_2016a_HIL_C_M));
    rtsiSetStepSizePtr(&gate_V37_2016a_HIL_C_M->solverInfo,
                       &gate_V37_2016a_HIL_C_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&gate_V37_2016a_HIL_C_M->solverInfo,
                          (&rtmGetErrorStatus(gate_V37_2016a_HIL_C_M)));
    rtsiSetRTModelPtr(&gate_V37_2016a_HIL_C_M->solverInfo,
                      gate_V37_2016a_HIL_C_M);
  }

  rtsiSetSimTimeStep(&gate_V37_2016a_HIL_C_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&gate_V37_2016a_HIL_C_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(gate_V37_2016a_HIL_C_M, &gate_V37_2016a_HIL_C_M->Timing.tArray[0]);
  gate_V37_2016a_HIL_C_M->Timing.stepSize0 = 0.001;

  /* block I/O */
  (void) memset(((void *) &gate_V37_2016a_HIL_C_B), 0,
                sizeof(B_gate_V37_2016a_HIL_C_T));

  /* states (dwork) */
  (void) memset((void *)&gate_V37_2016a_HIL_C_DW, 0,
                sizeof(DW_gate_V37_2016a_HIL_C_T));

  /* InitializeConditions for UnitDelay: '<S30>/Unit Delay' */
  gate_V37_2016a_HIL_C_DW.UnitDelay_DSTATE =
    gate_V37_2016a_HIL_C_P.UnitDelay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S30>/Unit Delay1' */
  gate_V37_2016a_HIL_C_DW.UnitDelay1_DSTATE =
    gate_V37_2016a_HIL_C_P.UnitDelay1_InitialCondition;

  /* SystemInitialize for Chart: '<S30>/rightSquareWaveDetector' */
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c22_gate_V37_2016a_HI = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c22_gate_V37_2016a_HIL_C = 0U;
  gate_V37_2016a_HIL_C_DW.counterHigh = 0U;
  gate_V37_2016a_HIL_C_DW.counterLow = 0U;
  gate_V37_2016a_HIL_C_B.currentValue = 0U;

  /* SystemInitialize for Chart: '<S30>/leftSquareWaveDetector' */
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_Running_p = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c1_gate_V37_2016a_HIL = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c1_gate_V37_2016a_HIL_C = 0U;
  gate_V37_2016a_HIL_C_DW.counterHigh_i = 0U;
  gate_V37_2016a_HIL_C_DW.counterLow_l = 0U;
  gate_V37_2016a_HIL_C_B.currentValue_p = 0U;

  /* SystemInitialize for Chart: '<S24>/GateLogicStatemachine' */
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closed = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_closing = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_open = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_opening = 0U;
  gate_V37_2016a_HIL_C_DW.temporalCounter_i2 = 0UL;
  gate_V37_2016a_HIL_C_DW.temporalCounter_i1 = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_active_c24_gate_V37_2016a_HI = 0U;
  gate_V37_2016a_HIL_C_DW.bitsForTID1.is_c24_gate_V37_2016a_HIL_C = 0U;
  gate_V37_2016a_HIL_C_DW.openingActive = 0U;
  gate_V37_2016a_HIL_C_DW.closing_active = 0U;
  gate_V37_2016a_HIL_C_B.leftMotor = 0U;
  gate_V37_2016a_HIL_C_B.rightMotor = 0U;
  gate_V37_2016a_HIL_C_B.bulbPin_BOOL = false;
  gate_V37_2016a_HIL_C_B.gateState = 0U;

  /* SystemInitialize for Chart: '<S26>/MotorsHandler' */
  gate_V37_2016a_HIL_C_B.LeftMotorPin_BOOL = false;
  gate_V37_2016a_HIL_C_B.ComMotorPin_BOOL = true;
  gate_V37_2016a_HIL_C_B.RightMotorPin_BOOL = false;
}

/* Model terminate function */
void gate_V37_2016a_HIL_C_terminate(void)
{
  /* (no terminate code required) */
}
